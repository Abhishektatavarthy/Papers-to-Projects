# Paper ↔ code conformance report

Paper: *Neural Message Passing for Quantum Chemistry* (Gilmer et al., ICML 2017).
Everything below was checked against the PDF text provided. The paper's **supplementary material was not available**, and **QM9 could not be downloaded in the build sandbox** (no network access to it).

## 1. What was verified, and how

`verify_against_paper.py` runs 29 hard checks (all pass): 8 numerical-equivalence, 16 constants, 4 Table-2 transcription, 1 towers-parameter check; plus one informational timing.

| Evidence | Result |
|---|---|
| `python verify_against_paper.py` – independent naive per-node loops implementing eqs. (1)–(3) vs. the vectorised model (edge-network, matrix, pair message × set2set, GG-NN readout; 9-atom molecule; also shown to be sensitive to the weights, so not vacuous) | 6/6 match to float precision (≤3e-7) |
| Same script – literal set2set algorithm vs. `Set2Set` on a *padded* batch | match (padding correctly ignored) |
| Same script – invariance to atom relabelling (graph isomorphism, Sec. 2) | max diff 9e-8 |
| Same script – 16 constants / design details stated in the paper (13 Table-1 features, bins, alphabet 14, 5-dim edge, 2d message, tied GRU, T/M/LR/F ranges and sampler, batch 20, 3M steps, ~540 epochs, 10k/10k split, 50 trials, top-5 ensemble, LR schedule, 13 targets) | 16/16 |
| Same script – transcription check of Table 2: enn-s2s column averages 0.678 (paper 0.68), ens5 0.525 (paper 0.52), 11/13 targets < 1, only *gap* and *ZPVE* ≥ 1 | consistent with the paper's text |
| `pytest tests` – 52 tests: shapes/gradients for all message×readout×edge-mode combos, permutation & padding invariance (incl. towers, master node), distance-bin edges, RDKit featurisation on real molecules (benzene aromatic/sp2, acetonitrile sp, ethanol donor/acceptor, H counts, units), xyz parsing for ω₁/partial charge, LR schedule, split, normalisation, end-to-end training + hparam search + ensembling | 52/52 pass |
| Learning sanity check on synthetic structure+geometry targets (700 steps, CPU) | test MAE 0.84 vs 5.20 for predicting the mean (6.2× better) |

## 2. Component-by-component mapping

| Paper | Where | Status |
|---|---|---|
| Eq. 1 message sum over neighbours | `layers.py` `*Message.forward` | ✅ verified vs naive loops |
| Eq. 2 GRU vertex update, weights tied over t (Sec. 5) | `layers.py` `Tower`, one `GRUCell` reused for all T | ✅ |
| Eq. 3 permutation-invariant readout | `layers.py` `GGNNReadout`, `Set2Set` | ✅ invariance tested |
| Undirected→directed, separate M_in/M_out, message size 2d (Sec. 5) | `DirectedMessage` | ✅ |
| Matrix-multiplication message `A_e h_w` (Sec. 5.1) | `MatrixMessage` | ✅ (computed via per-label neighbour sums — algebraically identical, verified vs naive `A[label]@h`) |
| **Edge network** `A(e_vw) h_w`, A(·): edge vector → d×d | `EdgeNetworkMessage` | ✅ |
| Pair message `f(h_w,h_v,e_vw)` | `PairMessage` | ✅ |
| Virtual edge type for unconnected pairs (Sec. 5.2) | `edge_mode="chemical_virtual"` | ✅ |
| Master node with own `d_master` and own GRU (Sec. 5.2) | `model.py` (`master=True`) | ✅ (wiring details are my interpretation, see §3) |
| GG-NN readout eq. 4 with `i(h_T,h_0)`, `j(h_T)` | `GGNNReadout` | ✅ + MLP head (see §3) |
| Set2set on projected `(h_T, x_v)`, M steps, then NN | `Set2Set` | ✅ verified vs literal algorithm |
| Towers: k copies of d/k dims, separate message/update fns, shared mixing net g (eq. 5) | `model.py`, `Tower` | ✅ params shrink 8.0× for k=8 |
| Table 1 atom features (13) | `data.preprocess` | ✅ tested on real molecules |
| Explicit-H nodes (≤29) / heavy-atom only | `MolDataset(explicit_h=…)` | ✅ |
| Chemical-graph / distance-bin (14 symbols; 8 uniform bins on [2,6] + [0,2] + [6,∞)) / raw 5-dim edges | `data.build_edges` | ✅ |
| Partial-charge feature only in Tables 3–4 | `--use_partial_charge` | ✅ (needs `--xyz_dir`) |
| Random split 10k/10k/rest; targets → mean 0, var 1 | `make_split`, `Normalizer` (fit on train) | ✅ |
| MSE loss, MAE metric, Adam, batch 20, 3M steps | `train.py` | ✅ |
| LR: uniform [1e-5,5e-4]; linear decay from 10–90% of training to l·F, F∈[.01,1] | `lr_multiplier`, `hparam_search.py` | ✅ |
| 50-trial random search, T∈[3,8], M∈[1,12] | `hparam_search.py` | ✅ |
| Validation-based early stopping / model selection | best-validation checkpoint restored | ✅ |
| One model per target; joint training also possible | `--targets` | ✅ |
| Ensemble of the 5 lowest-validation-error models | `ensemble.py` (mean of predictions) | ✅ |
| Error ratio = MAE / chemical accuracy | `train.error_ratios` | ✅ (values: see ⚠ below) |
| Presets for Table 2/3/4 and pair message | `presets.py`, `scripts/run_paper_experiments.sh` | ✅ |

## 3. Deviations, guesses and things the paper does not specify

These are the places where the code **cannot** be claimed to match the paper, because the paper is silent or the input was unavailable.

1. ⚠ **Chemical-accuracy values** (`constants.CHEMICAL_ACCURACY`) are *not in the PDF*; the paper defers them to its supplementary material / Faber et al. 2017. The numbers used are from my recollection of that table. **Check them against the supplementary before quoting any error ratio.** MAEs are unaffected; only the ratios scale.
2. ⚠ **Dataset size.** The paper states 130,462 molecules. The standard QM9 preprocessing (sdf + list of 3,054 "uncharacterized" molecules) is expected to yield ~130,831; I could not run it on the real download here. The split *protocol* matches (10k/10k/rest) but not necessarily the identical molecule set/split of Faber et al., so numbers are not strictly comparable to Table 2.
3. ⚠ **ω₁ (highest vibrational frequency)** is not in QM9's sdf/csv; it is only in the raw `.xyz` files, hence `--xyz_dir`. Without it, only 12 of the 13 targets can be trained.
4. **Unspecified hyper-parameters** (my choices, all exposed as flags): hidden size *d* (default 64; search samples {64,128}; 200 for the Table-4 presets, taken from the paper's speed-up example), edge-network hidden width 128, set2set projection size 128, readout head MLP, tower mixing net *g* (2-layer MLP), the `i`/`j` nets in eq. 4 (single linear layers + MLP head).
5. **Donor/acceptor and hybridisation** are computed with RDKit (`BaseFeatures.fdef`, `Hybridization`). The paper does not name the tool, so labels could differ slightly from theirs.
6. **Master node**: the paper gives only a prose description. I implemented master→node and node→master as bias-free linear maps (the "special edge type" matrices) with a separate GRU for the master state, initialised to zeros.
7. **Tables 3–4 details** not given in the paper (whether hydrogens were explicit, exact *d*): I assumed heavy atoms only; d = 200 for Table 4.
8. **Not implemented** (not part of the paper's contributions): the hand-engineered-feature baselines (CM, BoB, BAML, ECFP4, HDAD), and the other literature MPNN instances (Duvenaud, Interaction Networks, Kearnes graph-conv with learned edge states, DTNN, Laplacian/GCN). The GG-NN family, which the paper builds on, is included.
9. **Set2set internals** come from Vinyals et al. 2015 (LSTM query, dot-product attention), since this paper does not restate them.
10. **Distance units** assumed Å (QM9 positions); the bin edges [2,6] are applied to these.

## 4. What has NOT been done (no claim is made)

* The **published numbers of Table 2/3/4 have not been reproduced.** That needs the real QM9 data and roughly 3M steps × 50 trials × 13 targets of GPU training, which was impossible in the build sandbox (1 CPU core). The code, protocol and hyper-parameter ranges follow the paper; the results are for you to run (`scripts/run_paper_experiments.sh`).
* The real-data preprocessing path was tested on a hand-made mini dataset in QM9's file format (RDKit-generated molecules), not on the actual QM9 files.
* Timing: the towers benchmark (k=8, n=9, d=200) measured ×2.5 inference speed-up on 1 CPU thread with this implementation (paper: ≈×2, different implementation/hardware). Informational, not a conformance claim.

## 5. Verdict

The architecture, input representation, training protocol and model-selection procedure described in the paper are implemented and numerically checked against literal transcriptions of the paper's equations. The remaining risk is in the items of §3 (especially 1–3), which depend on data/supplementary material not available at build time.
