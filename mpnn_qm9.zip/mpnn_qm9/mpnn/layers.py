"""Building blocks of the MPNN framework (paper Sec. 2 and 5).

All tensors are dense & padded:  h [B,N,d],  edge tensors [B,N,N,...].
Because weights are tied over time steps (paper Sec. 5) and edge features are
constant, everything that depends only on edges is computed once in `prepare`
and re-used at every step -- mathematically identical to recomputing it.

A message module implements   m_v = sum_{w in N(v)} M(h_v, h_w, e_vw)   (eq. 1)
"""
from __future__ import annotations

from typing import NamedTuple, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class Graph(NamedTuple):
    edge_feat: torch.Tensor              # [B,N,N,E] float
    edge_mask: torch.Tensor              # [B,N,N]  bool
    edge_label: Optional[torch.Tensor]   # [B,N,N]  long (discrete modes only)


# ---------------------------------------------------------------------------
# Message functions (Sec. 5.1)
# ---------------------------------------------------------------------------
class MatrixMessage(nn.Module):
    """GG-NN message  M(h_v,h_w,e_vw) = A_{e_vw} h_w  (one learned d x d matrix per edge label).

    Implemented as  m_v = sum_l A_l ( sum_{w: label(v,w)=l} h_w )  which is exactly
    equal to the naive form but costs O(L n^2 d + L n d^2) instead of O(n^2 d^2).
    """
    def __init__(self, d: int, n_labels: int):
        super().__init__()
        self.L, self.out_dim = n_labels, d
        self.A = nn.Parameter(torch.randn(n_labels, d, d) / d ** 0.5)

    def prepare(self, g: Graph):
        if g.edge_label is None:
            raise ValueError("matrix message needs discrete edge labels "
                             "(edge_mode in chemical / chemical_virtual / distance_bins)")
        return F.one_hot(g.edge_label, self.L).float() * g.edge_mask.unsqueeze(-1)

    def forward(self, h, oh):
        S = torch.einsum("bvwl,bwj->bvlj", oh, h)          # per-label neighbour sums
        return torch.einsum("lij,bvlj->bvi", self.A, S)


class EdgeNetworkMessage(nn.Module):
    """Edge network (paper's novel message fn):  M = A(e_vw) h_w,
    where A(.) is a neural net mapping the edge vector to a d x d matrix."""
    def __init__(self, d: int, edge_dim: int, hidden: int = 128):
        super().__init__()
        self.d, self.out_dim = d, d
        self.net = nn.Sequential(nn.Linear(edge_dim, hidden), nn.ReLU(), nn.Linear(hidden, d * d))

    def prepare(self, g: Graph):
        B, N, _ = g.edge_mask.shape
        A = self.net(g.edge_feat).view(B, N, N, self.d, self.d)
        return A * g.edge_mask[..., None, None]

    def forward(self, h, A):
        return torch.einsum("bvwij,bwj->bvi", A, h)


class PairMessage(nn.Module):
    """Pair message (Battaglia et al.):  m_wv = f(h_w, h_v, e_vw), f an MLP.
    Depends on BOTH endpoints (the other two message fns do not depend on h_v)."""
    def __init__(self, d: int, edge_dim: int, hidden: Optional[int] = None):
        super().__init__()
        hidden = hidden or 2 * d
        self.out_dim = d
        self.net = nn.Sequential(nn.Linear(2 * d + edge_dim, hidden), nn.ReLU(), nn.Linear(hidden, d))

    def prepare(self, g: Graph):
        return g.edge_feat, g.edge_mask

    def forward(self, h, cache):
        ef, mask = cache
        B, N, _ = mask.shape
        hv = h[:, :, None, :].expand(B, N, N, -1)
        hw = h[:, None, :, :].expand(B, N, N, -1)
        msg = self.net(torch.cat([hv, hw, ef], dim=-1)) * mask.unsqueeze(-1)
        return msg.sum(dim=2)


class DirectedMessage(nn.Module):
    """Sec. 5: undirected chemical graphs are treated as directed; every bond is both an
    incoming and an outgoing edge with the same label, with separate functions M_in / M_out.
    The message is the concatenation (m_in, m_out) -> size 2d."""
    def __init__(self, make):
        super().__init__()
        self.m_in, self.m_out = make(), make()
        self.out_dim = 2 * self.m_in.out_dim

    def prepare(self, g):
        return self.m_in.prepare(g), self.m_out.prepare(g)

    def forward(self, h, cache):
        return torch.cat([self.m_in(h, cache[0]), self.m_out(h, cache[1])], dim=-1)


def make_message(kind: str, d: int, edge_dim: int, n_labels: Optional[int],
                 edge_hidden: int, directed: bool) -> nn.Module:
    def make():
        if kind == "matrix":
            return MatrixMessage(d, n_labels)
        if kind == "edge_network":
            return EdgeNetworkMessage(d, edge_dim, edge_hidden)
        if kind == "pair":
            return PairMessage(d, edge_dim)
        raise ValueError(f"unknown message function {kind!r}")
    if kind == "matrix" and n_labels is None:
        raise ValueError("matrix message requires a discrete edge_mode")
    return DirectedMessage(make) if directed else make()


# ---------------------------------------------------------------------------
# Tower = message fn + GRU update (Sec. 5, 5.4).   k = 1 is the ordinary MPNN step.
# ---------------------------------------------------------------------------
class Tower(nn.Module):
    def __init__(self, d: int, kind: str, edge_dim: int, n_labels, edge_hidden: int, directed: bool):
        super().__init__()
        self.message = make_message(kind, d, edge_dim, n_labels, edge_hidden, directed)
        self.gru = nn.GRUCell(self.message.out_dim, d)     # U_t = GRU, weights tied over t
        self.msg_dim = self.message.out_dim

    def prepare(self, g):
        return self.message.prepare(g)

    def step(self, h, cache, extra_msg=None):
        m = self.message(h, cache)                          # eq. (1)
        if extra_msg is not None:
            m = m + extra_msg
        B, N, d = h.shape
        return self.gru(m.reshape(B * N, -1), h.reshape(B * N, d)).view(B, N, d)   # eq. (2)


# ---------------------------------------------------------------------------
# Readout functions (Sec. 5.3).  Both are invariant to node permutation.
# ---------------------------------------------------------------------------
def mlp(i, h, o):
    return nn.Sequential(nn.Linear(i, h), nn.ReLU(), nn.Linear(h, o))


class GGNNReadout(nn.Module):
    """Eq. (4):  R = sum_v sigmoid(i(h_v^T, h_v^0)) * j(h_v^T);  i, j are (linear) networks.
    A small MLP head maps the pooled vector to the n_out targets (head size not in paper)."""
    def __init__(self, d: int, r_dim: int, n_out: int):
        super().__init__()
        self.i = nn.Linear(2 * d, r_dim)
        self.j = nn.Linear(d, r_dim)
        self.head = mlp(r_dim, r_dim, n_out)

    def forward(self, hT, h0, x, mask):
        gate = torch.sigmoid(self.i(torch.cat([hT, h0], -1)))
        pooled = (gate * self.j(hT) * mask.unsqueeze(-1)).sum(1)
        return self.head(pooled)


class Set2Set(nn.Module):
    """Set2set (Vinyals et al. 2015) as used in Sec. 5.3.

    1. linearly project each tuple (h_v^T, x_v)  -> memory m_v
    2. M steps of:  q_t = LSTM(q*_{t-1});  a_v = softmax_v(<m_v, q_t>);
                    r_t = sum_v a_v m_v;    q*_t = [q_t, r_t]
    3. q*_M is order-invariant; an MLP maps it to the output.
    """
    def __init__(self, in_dim: int, proj_dim: int, steps: int, n_out: int):
        super().__init__()
        self.proj = nn.Linear(in_dim, proj_dim)
        self.lstm = nn.LSTMCell(2 * proj_dim, proj_dim)
        self.steps, self.pd = steps, proj_dim
        self.head = mlp(2 * proj_dim, proj_dim, n_out)

    def forward(self, hT, h0, x, mask):
        m = self.proj(torch.cat([hT, x], -1))                    # [B,N,pd]
        B = m.shape[0]
        q_star = m.new_zeros(B, 2 * self.pd)
        hc = (m.new_zeros(B, self.pd), m.new_zeros(B, self.pd))
        for _ in range(self.steps):
            hc = self.lstm(q_star, hc)
            q = hc[0]
            e = (m * q.unsqueeze(1)).sum(-1).masked_fill(~mask, float("-inf"))
            a = torch.softmax(e, dim=-1)
            r = (a.unsqueeze(-1) * m).sum(1)
            q_star = torch.cat([q, r], -1)
        return self.head(q_star)
