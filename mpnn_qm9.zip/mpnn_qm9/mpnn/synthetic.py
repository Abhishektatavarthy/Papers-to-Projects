"""Tiny synthetic stand-in for processed QM9 (same format as data.preprocess output).

Used ONLY for tests / smoke runs where QM9 can't be downloaded.  Targets are simple
deterministic functions of structure so a working model can visibly learn them.
"""
from __future__ import annotations

import numpy as np

from .constants import ATOM_TYPES, N_ATOM_FEATURES, TARGETS


def make_synthetic(n_mols: int = 400, max_atoms: int = 12, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    out = dict(x=[], pos=[], bonds=[], heavy=[], charge=[], y=[], names=[], has_xyz=True)
    W = rng.normal(size=(len(TARGETS), 6))
    for m in range(n_mols):
        n = int(rng.integers(4, max_atoms + 1))
        types = rng.integers(0, 5, size=n)
        types[0] = 1                                        # guarantee >= 1 heavy atom
        z = np.array(ATOM_TYPES)[types]
        pos = (rng.normal(size=(n, 3)) * 1.6).astype(np.float32)
        dist = np.linalg.norm(pos[:, None] - pos[None], axis=-1)
        bonds = np.zeros((n, n), np.int8)
        for i in range(n):
            for j in range(i + 1, n):
                if dist[i, j] < 2.0:
                    bonds[i, j] = bonds[j, i] = rng.integers(1, 5)
        x = np.zeros((n, N_ATOM_FEATURES), np.float32)
        x[np.arange(n), types] = 1.0
        x[:, 5] = z
        x[:, 6:9] = rng.integers(0, 2, size=(n, 3))
        hyb = rng.integers(0, 4, size=n)                     # 0 = null
        for h in (1, 2, 3):
            x[hyb == h, 8 + h] = 1.0
        x[:, 12] = (bonds > 0).sum(1)
        iu = np.triu_indices(n, 1)
        feats = np.array([
            (bonds > 0).sum() / 2, z.sum() / 10, (1.0 / (dist[iu] + 0.5)).sum() / 5,
            ((pos - pos.mean(0)) ** 2).sum() / 10, x[:, 8].sum(), (types == 0).sum()])
        y = (W @ feats + 0.01 * rng.normal(size=len(TARGETS))).astype(np.float32)
        out["x"].append(x); out["pos"].append(pos); out["bonds"].append(bonds)
        out["heavy"].append(types != 0); out["charge"].append(rng.normal(size=n).astype(np.float32))
        out["y"].append(y); out["names"].append(f"syn_{m}")
    out["y"] = np.stack(out["y"])
    return out
