"""Named model/input configurations for the experiments in the paper.

Each preset = (edge_mode, explicit_h, MPNNConfig overrides).
"""

PRESETS = {
    # ---- Table 2, best model: edge network + set2set, explicit H, raw distance + bond type
    "enn-s2s": dict(edge_mode="raw_distance", explicit_h=True,
                    model=dict(message="edge_network", readout="set2set")),
    # ---- Table 2 baseline "GG-NN" trained with distance bins
    "ggnn-bins": dict(edge_mode="distance_bins", explicit_h=False,
                      model=dict(message="matrix", readout="ggnn")),
    # ---- Table 4: towers vs vanilla GG-NN (set2set output, distance bins, no explicit H)
    "ggnn-s2s-bins": dict(edge_mode="distance_bins", explicit_h=False,
                          model=dict(message="matrix", readout="set2set", hidden_dim=200)),
    "towers8-s2s-bins": dict(edge_mode="distance_bins", explicit_h=False,
                             model=dict(message="matrix", readout="set2set", hidden_dim=200, towers=8)),
    # ---- Table 3: no spatial information (chemical graph only)
    "nospatial-ggnn": dict(edge_mode="chemical", explicit_h=False,
                           model=dict(message="matrix", readout="ggnn")),
    "nospatial-virtual": dict(edge_mode="chemical_virtual", explicit_h=False,
                              model=dict(message="matrix", readout="ggnn")),
    "nospatial-master": dict(edge_mode="chemical", explicit_h=False,
                             model=dict(message="matrix", readout="ggnn", master=True)),
    "nospatial-s2s": dict(edge_mode="chemical", explicit_h=False,
                          model=dict(message="matrix", readout="set2set")),
    # ---- Sec. 8 "Additional experiments": pair message (paper: worse than edge network)
    "pair-s2s": dict(edge_mode="raw_distance", explicit_h=True,
                     model=dict(message="pair", readout="set2set")),
}
