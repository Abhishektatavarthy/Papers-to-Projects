"""Ensembling + Table-2-style report (paper Sec. 8).

Paper: "We were able to further improve performance on the test set by ensembling the
predictions of the five models with lowest validation error."  We average the test
predictions (original units) of the k best trials, ranked by validation MAE.

Usage:  python -m mpnn.ensemble --runs runs/enn-s2s [--targets all] [--top_k 5]
expects  runs/enn-s2s/<target>/trial_XX/{results.npz,metrics.json}
"""
from __future__ import annotations

import argparse
import glob
import json
import os

import numpy as np

from .constants import (CHEMICAL_ACCURACY, PAPER_ENN_S2S, PAPER_ENN_S2S_AVG, PAPER_ENN_S2S_ENS5,
                        PAPER_ENS5_AVG, PAPER_ENSEMBLE_K, TARGETS)


def ensemble_target(target_dir: str, target: str, top_k: int = PAPER_ENSEMBLE_K):
    trials = []
    for d in sorted(glob.glob(os.path.join(target_dir, "trial_*"))):
        mp, rp = os.path.join(d, "metrics.json"), os.path.join(d, "results.npz")
        if os.path.exists(mp) and os.path.exists(rp):
            m = json.load(open(mp))
            trials.append((m["val_ratio_mean"], d, np.load(rp)))
    if not trials:
        return None
    trials.sort(key=lambda t: t[0])                        # lowest validation error first
    ca = CHEMICAL_ACCURACY[target]
    best = trials[0]
    single = np.abs(best[2]["test_pred"] - best[2]["test_true"]).mean() / ca
    chosen = trials[:top_k]
    ens_pred = np.mean([t[2]["test_pred"] for t in chosen], axis=0)
    ens = np.abs(ens_pred - chosen[0][2]["test_true"]).mean() / ca
    return dict(single=float(single), ensemble=float(ens), n_trials=len(trials), n_ens=len(chosen))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--targets", nargs="+", default=["all"])
    ap.add_argument("--top_k", type=int, default=PAPER_ENSEMBLE_K)
    a = ap.parse_args()
    targets = TARGETS if a.targets == ["all"] else a.targets
    print(f"{'target':8s} {'trials':>6s} {'single':>8s} {'ens'+str(a.top_k):>8s}   |  paper enn-s2s  ens5")
    S, E = [], []
    for t in targets:
        r = ensemble_target(os.path.join(a.runs, t), t, a.top_k)
        if r is None:
            print(f"{t:8s}   (no finished trials)"); continue
        S.append(r["single"]); E.append(r["ensemble"])
        print(f"{t:8s} {r['n_trials']:6d} {r['single']:8.3f} {r['ensemble']:8.3f}   |  "
              f"{PAPER_ENN_S2S[t]:10.2f} {PAPER_ENN_S2S_ENS5[t]:6.2f}")
    if S:
        print(f"{'average':8s} {'':6s} {np.mean(S):8.3f} {np.mean(E):8.3f}   |  "
              f"{PAPER_ENN_S2S_AVG:10.2f} {PAPER_ENS5_AVG:6.2f}   (error ratio; <1 = chemical accuracy)")


if __name__ == "__main__":
    main()
