"""Uniform random hyper-parameter search (paper Sec. 7).

Paper: 50 trials per (model, target); T in [3,8]; set2set steps M in [1,12];
initial LR uniform in [1e-5, 5e-4]; linear decay beginning 10%-90% of the way through
training, decaying to l*F with F in [0.01, 1].

NOT specified in the paper (our choices, exposed as flags): the hidden size d, the
edge-network / readout widths.  We sample d from --hidden_dims (default 64 128).

Trials are resumable: a finished trial (metrics.json present) is skipped.
"""
from __future__ import annotations

import argparse
import copy
import json
import os

import numpy as np

from .constants import (PAPER_DECAY_FACTOR_RANGE, PAPER_DECAY_START_RANGE, PAPER_LR_RANGE,
                        PAPER_N_TRIALS, PAPER_S2S_RANGE, PAPER_T_RANGE, TARGETS)
from .train import TrainConfig, build_parser, config_from_args, run


def sample_config(base: TrainConfig, rng: np.random.RandomState, hidden_dims) -> TrainConfig:
    cfg = copy.deepcopy(base)
    cfg.model.mp_steps = int(rng.randint(PAPER_T_RANGE[0], PAPER_T_RANGE[1] + 1))          # T
    if cfg.model.readout == "set2set":
        cfg.model.s2s_steps = int(rng.randint(PAPER_S2S_RANGE[0], PAPER_S2S_RANGE[1] + 1))  # M
    cfg.lr = float(rng.uniform(*PAPER_LR_RANGE))
    cfg.decay_start = float(rng.uniform(*PAPER_DECAY_START_RANGE))
    cfg.decay_factor = float(rng.uniform(*PAPER_DECAY_FACTOR_RANGE))
    ok = [d for d in hidden_dims if d % cfg.model.towers == 0]
    cfg.model.hidden_dim = int(rng.choice(ok))
    cfg.seed = int(rng.randint(0, 2 ** 31 - 1))
    return cfg


def main():
    p = build_parser()
    p.add_argument("--trials", type=int, default=PAPER_N_TRIALS)
    p.add_argument("--search_seed", type=int, default=0)
    p.add_argument("--hidden_dims", type=int, nargs="+", default=[64, 128])
    a = p.parse_args()
    targets = list(TARGETS) if a.targets == ["all"] else a.targets
    for t in targets:                                   # one search (and one model family) per target
        a.targets = [t]
        base = config_from_args(a)
        root = os.path.join(a.out_dir, t) if a.out_dir else f"runs/{a.preset}/{t}"
        rng = np.random.RandomState(a.search_seed + TARGETS.index(t))
        for k in range(a.trials):
            cfg = sample_config(base, rng, a.hidden_dims)      # always draw -> resume stays deterministic
            cfg.out_dir = os.path.join(root, f"trial_{k:02d}")
            if os.path.exists(os.path.join(cfg.out_dir, "metrics.json")):
                print(f"skip {cfg.out_dir} (done)"); continue
            m = run(cfg)
            print(f"trial {k}: val ratio {m['val_ratio_mean']:.4f}  test ratio {m['test_ratio_mean']:.4f}")


if __name__ == "__main__":
    main()
