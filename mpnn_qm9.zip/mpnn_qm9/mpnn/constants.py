"""Constants taken from (or needed to reproduce) Gilmer et al. 2017,
"Neural Message Passing for Quantum Chemistry".

NOTE on provenance
------------------
* TARGETS / UNITS / paper result tables: taken from the paper text (Sec. 4, Table 2).
* CHEMICAL_ACCURACY: the paper says these are listed in its *supplementary
  material* (same values as Faber et al. 2017). The supplementary is NOT part of
  the PDF this project was built from, so the numbers below are from the
  well-known Faber et al. / MPNN-supplementary table and MUST be double-checked
  against the supplementary before quoting error ratios.
"""

# The 13 regression targets of QM9 used in the paper (order of Table 2).
TARGETS = ["mu", "alpha", "homo", "lumo", "gap", "r2", "zpve",
           "u0", "u", "h", "g", "cv", "omega1"]

UNITS = {
    "mu": "Debye", "alpha": "Bohr^3", "homo": "eV", "lumo": "eV", "gap": "eV",
    "r2": "Bohr^2", "zpve": "eV", "u0": "eV", "u": "eV", "h": "eV", "g": "eV",
    "cv": "cal/(mol K)", "omega1": "cm^-1",
}

# See provenance note above (supplementary material / Faber et al. 2017).
CHEMICAL_ACCURACY = {
    "mu": 0.1, "alpha": 0.1, "homo": 0.043, "lumo": 0.043, "gap": 0.043,
    "r2": 1.2, "zpve": 0.0012, "u0": 0.043, "u": 0.043, "h": 0.043,
    "g": 0.043, "cv": 0.050, "omega1": 28.0,
}

# Paper Table 2 (error ratio = MAE / chemical accuracy), for comparison reports.
PAPER_ENN_S2S = {
    "mu": 0.30, "alpha": 0.92, "homo": 0.99, "lumo": 0.87, "gap": 1.60,
    "r2": 0.15, "zpve": 1.27, "u0": 0.45, "u": 0.45, "h": 0.39, "g": 0.44,
    "cv": 0.80, "omega1": 0.19,
}
PAPER_ENN_S2S_ENS5 = {
    "mu": 0.20, "alpha": 0.68, "homo": 0.74, "lumo": 0.65, "gap": 1.23,
    "r2": 0.14, "zpve": 1.10, "u0": 0.33, "u": 0.34, "h": 0.30, "g": 0.34,
    "cv": 0.62, "omega1": 0.15,
}
PAPER_ENN_S2S_AVG = 0.68
PAPER_ENS5_AVG = 0.52

# Unit conversions (Hartree -> eV, kcal/mol -> eV).
HAR2EV = 27.211386246
KCALMOL2EV = 0.04336414

# ---- Paper hyper-parameters (Sec. 7 "Training") ---------------------------
PAPER_BATCH_SIZE = 20
PAPER_STEPS = 3_000_000
PAPER_N_VAL = 10_000
PAPER_N_TEST = 10_000
PAPER_N_TRIALS = 50
PAPER_T_RANGE = (3, 8)          # message-passing steps
PAPER_S2S_RANGE = (1, 12)       # set2set computations M
PAPER_LR_RANGE = (1e-5, 5e-4)   # initial learning rate (uniform)
PAPER_DECAY_START_RANGE = (0.1, 0.9)   # fraction of training when decay starts
PAPER_DECAY_FACTOR_RANGE = (0.01, 1.0)  # final LR = l * F
PAPER_ENSEMBLE_K = 5

# ---- Input representation (Sec. 6, Table 1) -------------------------------
ATOM_TYPES = (1, 6, 7, 8, 9)  # H, C, N, O, F
ATOM_FEATURE_NAMES = (
    ["type_H", "type_C", "type_N", "type_O", "type_F"]
    + ["atomic_number", "acceptor", "donor", "aromatic",
       "sp", "sp2", "sp3", "num_hydrogens"]
)
N_ATOM_FEATURES = len(ATOM_FEATURE_NAMES)  # 13 (+1 optional partial charge)

# Distance bins: 8 uniform bins over [2, 6] + [0, 2] + [6, inf) = 10 bins.
DIST_LOW, DIST_HIGH, DIST_N_UNIFORM = 2.0, 6.0, 8
N_DIST_BINS = DIST_N_UNIFORM + 2      # 10
N_BOND_TYPES = 4                       # single, double, triple, aromatic
N_DISTANCE_BIN_LABELS = N_BOND_TYPES + N_DIST_BINS  # 14 (paper: "alphabet of size 14")
