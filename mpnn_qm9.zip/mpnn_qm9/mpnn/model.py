"""Message Passing Neural Network (paper Sec. 2, 5).

Forward pass
    h^0_v = x_v (zero-padded to d)
    for t in 1..T:                       # message passing phase
        m_v = sum_w M(h_v, h_w, e_vw)    # eq. 1   (message fn, in/out channels -> 2d)
        h_v = GRU(h_v, m_v)              # eq. 2   (weights tied across t)
        [towers]  h_v = g(concat_k h~^k_v)          # eq. 5
        [master]  master node reads all nodes / writes to all nodes
    y = R({h^T_v})                       # eq. 3   (set2set or GG-NN readout)
"""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F

from .data import EDGE_MODES, Batch
from .layers import GGNNReadout, Graph, Set2Set, Tower, mlp


@dataclass
class MPNNConfig:
    hidden_dim: int = 64          # d   (range not given in the paper)
    mp_steps: int = 6             # T   message-passing steps (paper searches 3..8)
    message: str = "edge_network"  # edge_network | matrix | pair
    readout: str = "set2set"      # set2set | ggnn
    s2s_steps: int = 6            # M   (paper searches 1..12)
    readout_dim: int = 128        # projection / pooled size in the readout (not in paper)
    towers: int = 1               # k   (Sec. 5.4)
    master: bool = False          # Sec. 5.2 master node
    master_dim: int = 64          # d_master
    directed: bool = True         # separate in/out message channels -> message size 2d
    edge_hidden: int = 128        # hidden width of the edge network (not in paper)


class MPNN(nn.Module):
    def __init__(self, cfg: MPNNConfig, node_dim: int, edge_mode: str, n_out: int = 1):
        super().__init__()
        info = EDGE_MODES[edge_mode]
        self.cfg, self.node_dim, self.n_labels = cfg, node_dim, info["n_labels"]
        d, k = cfg.hidden_dim, cfg.towers
        if d < node_dim:
            raise ValueError(f"hidden_dim ({d}) must be >= node feature dim ({node_dim})")
        if d % k:
            raise ValueError(f"hidden_dim ({d}) must be divisible by towers ({k})")
        if k > 1 and cfg.master:
            raise ValueError("towers + master node is not supported (not explored in the paper)")
        if cfg.message == "matrix" and info["kind"] != "label":
            raise ValueError("matrix message needs a discrete edge_mode "
                             "(chemical / chemical_virtual / distance_bins)")

        self.towers = nn.ModuleList([
            Tower(d // k, cfg.message, info["edge_dim"], info["n_labels"], cfg.edge_hidden, cfg.directed)
            for _ in range(k)])
        # eq. (5): shared mixing network g  (only for k > 1)
        self.mix = nn.Sequential(nn.Linear(d, d), nn.ReLU(), nn.Linear(d, d)) if k > 1 else None

        if cfg.master:
            msg_dim = self.towers[0].msg_dim
            # master --(special edge type, matrix mult)--> nodes ;  nodes --> master
            self.master_to_node = nn.Linear(cfg.master_dim, msg_dim, bias=False)
            self.node_to_master = nn.Linear(d, cfg.master_dim, bias=False)
            self.master_gru = nn.GRUCell(cfg.master_dim, cfg.master_dim)   # separate weights

        if cfg.readout == "set2set":
            self.readout = Set2Set(d + node_dim, cfg.readout_dim, cfg.s2s_steps, n_out)
        elif cfg.readout == "ggnn":
            self.readout = GGNNReadout(d, cfg.readout_dim, n_out)
        else:
            raise ValueError(f"unknown readout {cfg.readout!r}")

    def forward(self, b: Batch) -> torch.Tensor:
        cfg, d, k = self.cfg, self.cfg.hidden_dim, self.cfg.towers
        x, mask = b.x, b.node_mask
        g = Graph(b.edge_features(self.n_labels), b.edge_mask, b.edge_label)
        caches = [tw.prepare(g) for tw in self.towers]      # edge-only work, done once

        h0 = F.pad(x, (0, d - x.shape[-1]))                 # h^0_v = x_v padded up to d
        h = h0
        maskf = mask.unsqueeze(-1).to(x.dtype)
        hm = x.new_zeros(x.shape[0], cfg.master_dim) if cfg.master else None

        for _ in range(cfg.mp_steps):
            if k == 1:
                extra = self.master_to_node(hm).unsqueeze(1) if cfg.master else None
                h_new = self.towers[0].step(h, caches[0], extra)
            else:                                            # towers: independent propagation + mixing
                parts = [tw.step(c, cache) for tw, c, cache in zip(self.towers, h.chunk(k, -1), caches)]
                h_new = self.mix(torch.cat(parts, -1))
            if cfg.master:                                   # simultaneous read/write with old states
                hm = self.master_gru((self.node_to_master(h) * maskf).sum(1), hm)
            h = h_new
        return self.readout(h, h0, x, mask)


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())
