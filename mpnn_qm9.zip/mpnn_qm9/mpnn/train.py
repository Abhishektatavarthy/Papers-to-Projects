"""Training (paper Sec. 7) and evaluation (Sec. 8).

Paper protocol implemented here
  * one model per target (default) or joint training over several targets
  * loss = MSE on targets normalised to mean 0 / variance 1; metric = MAE
  * Adam, batch size 20, 3M steps (~540 epochs)
  * LR: starts at l, constant until `decay_start` (fraction of training), then linear
    decay to l * F
  * 10k validation / 10k test / rest train; validation set used for early stopping /
    model selection (best-validation checkpoint is restored at the end)
  * report error ratio = MAE / chemical accuracy
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import time
from dataclasses import asdict, dataclass, field, fields

import numpy as np
import torch
import torch.nn.functional as F

from .constants import (CHEMICAL_ACCURACY, PAPER_BATCH_SIZE, PAPER_N_TEST, PAPER_N_VAL,
                        PAPER_STEPS, TARGETS)
from .data import (MolDataset, Normalizer, load_processed, make_loader, make_split,
                   node_feature_dim)
from .model import MPNN, MPNNConfig, count_parameters
from .presets import PRESETS
from .synthetic import make_synthetic


@dataclass
class TrainConfig:
    data_root: str = "data/qm9"
    xyz_dir: str | None = None
    targets: tuple = ("u0",)          # >1 target => joint training
    edge_mode: str = "raw_distance"
    explicit_h: bool = True
    use_partial_charge: bool = False
    model: MPNNConfig = field(default_factory=MPNNConfig)
    batch_size: int = PAPER_BATCH_SIZE
    steps: int = PAPER_STEPS
    lr: float = 1e-4                  # paper: initial LR ~ U(1e-5, 5e-4)
    decay_start: float = 0.5          # paper: 10%..90% of training
    decay_factor: float = 0.1         # paper: F in [0.01, 1]
    grad_clip: float = 0.0            # 0 = off (paper does not mention clipping)
    eval_every: int = 10_000
    n_val: int = PAPER_N_VAL
    n_test: int = PAPER_N_TEST
    split_seed: int = 0
    seed: int = 0
    num_workers: int = 0
    device: str = "auto"
    out_dir: str = "runs/debug"
    synthetic: int = 0                # >0: use that many synthetic molecules (smoke tests)
    log_every: int = 1000


def lr_multiplier(step: int, total: int, start_frac: float, final_factor: float) -> float:
    """Constant LR until start_frac*total, then linear decay to final_factor (=F)."""
    s0 = int(start_frac * total)
    if step <= s0:
        return 1.0
    frac = min(1.0, (step - s0) / max(1, total - s0))
    return 1.0 + (final_factor - 1.0) * frac


@torch.no_grad()
def predict(model, loader, device, norm: Normalizer):
    """Returns (pred, true) in ORIGINAL units, shape [n, n_out]."""
    model.eval()
    P, Y = [], []
    for b in loader:
        b = b.to(device)
        P.append(norm.inverse(model(b).cpu().numpy())); Y.append(b.y.cpu().numpy())
    return np.concatenate(P), np.concatenate(Y)


def error_ratios(pred, true, targets):
    mae = np.abs(pred - true).mean(0)
    ratio = mae / np.array([CHEMICAL_ACCURACY[t] for t in targets])
    return mae, ratio


def run(cfg: TrainConfig, data: dict | None = None) -> dict:
    os.makedirs(cfg.out_dir, exist_ok=True)
    torch.manual_seed(cfg.seed); np.random.seed(cfg.seed)
    device = torch.device("cuda" if cfg.device == "auto" and torch.cuda.is_available()
                          else "cpu" if cfg.device == "auto" else cfg.device)
    if data is None:
        data = make_synthetic(cfg.synthetic, seed=cfg.split_seed) if cfg.synthetic \
            else load_processed(cfg.data_root, cfg.xyz_dir)
    t_idx = [TARGETS.index(t) for t in cfg.targets]
    y_all = data["y"][:, t_idx]
    if np.isnan(y_all).any():
        raise ValueError(f"targets {cfg.targets} contain NaN -- omega1 needs preprocessing with --xyz_dir")

    tr, va, te = make_split(len(y_all), cfg.n_val, cfg.n_test, cfg.split_seed)
    norm = Normalizer.fit(y_all[tr])
    mk = lambda idx: MolDataset(data, idx, t_idx, cfg.explicit_h, cfg.use_partial_charge)
    train_loader = make_loader(mk(tr), cfg.edge_mode, cfg.batch_size, True, cfg.num_workers, drop_last=True)
    val_loader = make_loader(mk(va), cfg.edge_mode, 100, False, cfg.num_workers)
    test_loader = make_loader(mk(te), cfg.edge_mode, 100, False, cfg.num_workers)

    model = MPNN(cfg.model, node_feature_dim(cfg.use_partial_charge), cfg.edge_mode, len(t_idx)).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: lr_multiplier(s, cfg.steps, cfg.decay_start, cfg.decay_factor))
    with open(os.path.join(cfg.out_dir, "config.json"), "w") as f:
        json.dump(asdict(cfg), f, indent=2, default=list)
    print(f"[{cfg.out_dir}] params={count_parameters(model):,} device={device} "
          f"train/val/test={len(tr)}/{len(va)}/{len(te)}")

    best_val, best_state, best_step, log = float("inf"), None, 0, []
    step, t0, running = 0, time.time(), []
    while step < cfg.steps:
        for b in train_loader:
            model.train()
            b = b.to(device)
            loss = F.mse_loss(model(b), norm(b.y))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if cfg.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step(); sched.step(); step += 1
            running.append(loss.item())
            if step % cfg.log_every == 0:
                print(f"  step {step:>8d}  loss {np.mean(running):.4f}  lr {sched.get_last_lr()[0]:.2e}  "
                      f"{time.time() - t0:.0f}s", flush=True)
                running = []
            if step % cfg.eval_every == 0 or step == cfg.steps:
                p, y = predict(model, val_loader, device, norm)
                _, ratio = error_ratios(p, y, cfg.targets)
                val = float(ratio.mean())
                log.append(dict(step=step, val_error_ratio=val))
                if val < best_val:      # model selection / early stopping on validation
                    best_val, best_step = val, step
                    best_state = copy.deepcopy(model.state_dict())
                print(f"  [eval] step {step} val error-ratio {val:.4f} (best {best_val:.4f} @ {best_step})", flush=True)
            if step >= cfg.steps:
                break

    model.load_state_dict(best_state)
    vp, vy = predict(model, val_loader, device, norm)
    tp, ty = predict(model, test_loader, device, norm)
    v_mae, v_ratio = error_ratios(vp, vy, cfg.targets)
    t_mae, t_ratio = error_ratios(tp, ty, cfg.targets)
    np.savez(os.path.join(cfg.out_dir, "results.npz"), val_pred=vp, val_true=vy, test_pred=tp, test_true=ty)
    torch.save(best_state, os.path.join(cfg.out_dir, "best.pt"))
    metrics = dict(targets=list(cfg.targets), best_step=best_step, val_mae=v_mae.tolist(),
                   val_ratio=v_ratio.tolist(), test_mae=t_mae.tolist(), test_ratio=t_ratio.tolist(),
                   val_ratio_mean=float(v_ratio.mean()), test_ratio_mean=float(t_ratio.mean()),
                   params=count_parameters(model), train_log=log)
    json.dump(metrics, open(os.path.join(cfg.out_dir, "metrics.json"), "w"), indent=2)
    print(f"[done] test error ratio: " + ", ".join(f"{t}={r:.3f}" for t, r in zip(cfg.targets, t_ratio)))
    return metrics


# ---------------------------------------------------------------------------
def build_parser():
    p = argparse.ArgumentParser(description="Train an MPNN on QM9 (Gilmer et al. 2017)")
    p.add_argument("--preset", choices=list(PRESETS), default="enn-s2s")
    p.add_argument("--targets", nargs="+", default=["u0"], help="one target = one model; several = joint training; 'all' = all 13")
    p.add_argument("--data_root", default="data/qm9"); p.add_argument("--xyz_dir", default=None)
    p.add_argument("--out_dir", default=None); p.add_argument("--device", default="auto")
    p.add_argument("--synthetic", type=int, default=0)
    p.add_argument("--use_partial_charge", action="store_true")
    for f in fields(TrainConfig):
        if f.name in {"model", "targets", "data_root", "xyz_dir", "out_dir", "device", "synthetic",
                      "use_partial_charge", "edge_mode", "explicit_h"}:
            continue
        p.add_argument(f"--{f.name}", type=type(f.default), default=None)
    for f in fields(MPNNConfig):
        if f.type in ("bool", bool):
            p.add_argument(f"--{f.name}", type=lambda s: s.lower() in ("1", "true", "yes"), default=None)
        else:
            p.add_argument(f"--{f.name}", type=type(f.default), default=None)
    p.add_argument("--edge_mode", default=None); p.add_argument("--explicit_h", type=lambda s: s.lower() in ("1", "true", "yes"), default=None)
    return p


def config_from_args(a) -> TrainConfig:
    pre = PRESETS[a.preset]
    targets = tuple(TARGETS) if a.targets == ["all"] else tuple(a.targets)
    model = MPNNConfig(**{**pre["model"]})
    cfg = TrainConfig(data_root=a.data_root, xyz_dir=a.xyz_dir, targets=targets,
                      edge_mode=pre["edge_mode"], explicit_h=pre["explicit_h"],
                      use_partial_charge=a.use_partial_charge, model=model,
                      device=a.device, synthetic=a.synthetic)
    for f in fields(TrainConfig):
        v = getattr(a, f.name, None)
        if f.name not in {"model", "targets"} and v is not None:
            setattr(cfg, f.name, v)
    for f in fields(MPNNConfig):
        v = getattr(a, f.name, None)
        if v is not None:
            setattr(cfg.model, f.name, v)
    cfg.out_dir = a.out_dir or f"runs/{a.preset}/{'-'.join(targets) if len(targets) < 4 else 'joint'}"
    return cfg


if __name__ == "__main__":
    run(config_from_args(build_parser().parse_args()))
