"""Data pipeline for QM9 (paper Sec. 4, 6, 7).

Steps implemented here
  1. QM9 loading / preprocessing (RDKit) -> atom features of Table 1
  2. random 10k / 10k / rest split, target normalisation (mean 0, var 1)
  3. the three edge representations of Sec. 6
        chemical graph  |  distance bins (alphabet 14)  |  raw distance (5-dim)
     (+ the "virtual edge" preprocessing of Sec. 5.2 as `chemical_virtual`)
  4. optional explicit hydrogens (up to 29 nodes) and optional partial charge
  5. dense, padded batching of variable-size graphs
"""
from __future__ import annotations

import csv
import os
import urllib.request
import zipfile
from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from .constants import (ATOM_TYPES, DIST_HIGH, DIST_LOW, DIST_N_UNIFORM, HAR2EV,
                        KCALMOL2EV, N_ATOM_FEATURES, N_BOND_TYPES,
                        N_DISTANCE_BIN_LABELS, TARGETS)

QM9_URL = "https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/molnet_publish/qm9.zip"
UNCHARACTERIZED_URL = "https://ndownloader.figshare.com/files/3195404"

# ---------------------------------------------------------------------------
# Edge representations
# ---------------------------------------------------------------------------
# kind == "label"  -> discrete edge alphabet (needed by the matrix-multiply message)
# kind == "vector" -> real-valued edge vector (needed by the edge network)
EDGE_MODES = {
    "chemical":         dict(kind="label",  n_labels=N_BOND_TYPES,          edge_dim=N_BOND_TYPES),
    "chemical_virtual": dict(kind="label",  n_labels=N_BOND_TYPES + 1,      edge_dim=N_BOND_TYPES + 1),
    "distance_bins":    dict(kind="label",  n_labels=N_DISTANCE_BIN_LABELS, edge_dim=N_DISTANCE_BIN_LABELS),
    "raw_distance":     dict(kind="vector", n_labels=None,                  edge_dim=1 + N_BOND_TYPES),
}

# 9 boundaries -> 8 uniform bins on [2, 6], plus (-inf, 2) and [6, inf) => 10 bins.
DIST_BOUNDARIES = torch.linspace(DIST_LOW, DIST_HIGH, DIST_N_UNIFORM + 1)


def node_feature_dim(use_partial_charge: bool = False) -> int:
    return N_ATOM_FEATURES + int(use_partial_charge)


def build_edges(pos: torch.Tensor, bonds: torch.Tensor, node_mask: torch.Tensor, mode: str):
    """Vectorised edge featurisation for a padded batch.

    pos [B,N,3] (Angstrom), bonds [B,N,N] long (0 = no bond, 1..4 = bond type),
    node_mask [B,N] bool.  Returns dict(edge_mask, edge_label|None, edge_attr|None).
    """
    if mode not in EDGE_MODES:
        raise ValueError(f"unknown edge_mode {mode!r}; choose from {list(EDGE_MODES)}")
    B, N, _ = pos.shape
    eye = torch.eye(N, dtype=torch.bool, device=pos.device)
    pair_mask = node_mask[:, :, None] & node_mask[:, None, :] & ~eye  # no self loops
    bonded = bonds > 0
    label = attr = None

    if mode == "chemical":
        # Sparse graph: edges exist only where there is a chemical bond.
        edge_mask = pair_mask & bonded
        label = (bonds - 1).clamp(min=0)
    elif mode == "chemical_virtual":
        # Sec. 5.2: extra "virtual" edge type for pairs that are not connected.
        edge_mask = pair_mask
        label = torch.where(bonded, bonds - 1, torch.full_like(bonds, N_BOND_TYPES))
    elif mode == "distance_bins":
        # Sec. 6: fully connected; label = bond type if bonded else distance bin.
        edge_mask = pair_mask
        dist = torch.cdist(pos, pos)
        bins = torch.bucketize(dist, DIST_BOUNDARIES.to(pos.device), right=True)  # 0..9
        label = torch.where(bonded, bonds - 1, N_BOND_TYPES + bins)              # 0..13
    else:  # raw_distance
        # Sec. 6: 5-d vector = [euclidean distance, one-hot bond type (4)].
        edge_mask = pair_mask
        dist = torch.cdist(pos, pos)
        onehot = F.one_hot(bonds.clamp(min=0), N_BOND_TYPES + 1)[..., 1:].to(pos.dtype)
        attr = torch.cat([dist.unsqueeze(-1), onehot], dim=-1)
    return dict(edge_mask=edge_mask, edge_label=label, edge_attr=attr)


@dataclass
class Batch:
    x: torch.Tensor                       # [B,N,F] atom features
    node_mask: torch.Tensor               # [B,N] bool
    edge_mask: torch.Tensor               # [B,N,N] bool  (which (v,w) pairs exchange messages)
    edge_label: Optional[torch.Tensor]    # [B,N,N] long  (discrete modes)
    edge_attr: Optional[torch.Tensor]     # [B,N,N,5] float (raw_distance)
    y: Optional[torch.Tensor] = None      # [B,n_out] targets in original units

    def to(self, device):
        f = lambda t: None if t is None else t.to(device)
        return Batch(f(self.x), f(self.node_mask), f(self.edge_mask),
                     f(self.edge_label), f(self.edge_attr), f(self.y))

    def edge_features(self, n_labels: Optional[int]) -> torch.Tensor:
        """Float edge feature tensor [B,N,N,E] (one-hot for discrete labels)."""
        if self.edge_attr is not None:
            return self.edge_attr
        return F.one_hot(self.edge_label, n_labels).to(self.x.dtype)


# ---------------------------------------------------------------------------
# Preprocessing raw QM9 -> processed.pt   (needs RDKit; run once)
# ---------------------------------------------------------------------------
def download_qm9(raw_dir: str):
    os.makedirs(raw_dir, exist_ok=True)
    zpath = os.path.join(raw_dir, "qm9.zip")
    if not os.path.exists(os.path.join(raw_dir, "gdb9.sdf")):
        print(f"Downloading {QM9_URL} ...")
        urllib.request.urlretrieve(QM9_URL, zpath)
        with zipfile.ZipFile(zpath) as z:
            z.extractall(raw_dir)
    upath = os.path.join(raw_dir, "uncharacterized.txt")
    if not os.path.exists(upath):
        print(f"Downloading {UNCHARACTERIZED_URL} ...")
        urllib.request.urlretrieve(UNCHARACTERIZED_URL, upath)


def _read_skip(path: Optional[str]) -> set:
    """Indices (0-based) of the 3054 molecules that failed QM9's consistency check."""
    skip = set()
    if path and os.path.exists(path):
        for line in open(path).read().split("\n")[9:]:
            tok = line.split()
            if tok and tok[0].isdigit():
                skip.add(int(tok[0]) - 1)
    return skip


def _parse_xyz(path: str):
    """Parse a QM9 .xyz file: elements, coords, Mulliken charges, frequencies."""
    lines = open(path).read().split("\n")
    na = int(lines[0])
    fl = lambda s: float(s.replace("*^", "e"))
    elems, coords, charges = [], [], []
    for l in lines[2:2 + na]:
        p = l.split()
        elems.append(p[0]); coords.append([fl(v) for v in p[1:4]]); charges.append(fl(p[4]))
    freqs = [fl(v) for v in lines[2 + na].split()]
    return elems, np.array(coords), np.array(charges, dtype=np.float32), freqs


def _sanitize(mol):
    from rdkit import Chem
    try:
        Chem.SanitizeMol(mol)
        return True
    except Exception:
        mol.UpdatePropertyCache(strict=False)
        Chem.SanitizeMol(
            mol,
            Chem.SANITIZE_FINDRADICALS | Chem.SANITIZE_SETAROMATICITY |
            Chem.SANITIZE_SETCONJUGATION | Chem.SANITIZE_SETHYBRIDIZATION |
            Chem.SANITIZE_SYMMRINGS, catchErrors=True)
        return False


def preprocess(raw_dir: str, out_path: str, xyz_dir: Optional[str] = None,
               limit: Optional[int] = None, verbose: bool = True):
    """Build the processed QM9 cache.

    Needs raw_dir/gdb9.sdf and raw_dir/gdb9.sdf.csv (+ optional uncharacterized.txt).
    If `xyz_dir` (folder of dsgdb9nsd_XXXXXX.xyz) is given we additionally extract
    omega1 (highest vibrational frequency; NOT in the sdf/csv) and Mulliken partial
    charges.  Without it omega1 is NaN and only 12 targets are usable.
    """
    from rdkit import Chem, RDConfig
    from rdkit.Chem import ChemicalFeatures
    BT = Chem.BondType
    bond_map = {BT.SINGLE: 1, BT.DOUBLE: 2, BT.TRIPLE: 3, BT.AROMATIC: 4}
    HT = Chem.HybridizationType
    factory = ChemicalFeatures.BuildFeatureFactory(
        os.path.join(RDConfig.RDDataDir, "BaseFeatures.fdef"))

    rows = list(csv.DictReader(open(os.path.join(raw_dir, "gdb9.sdf.csv"))))
    skip = _read_skip(os.path.join(raw_dir, "uncharacterized.txt"))
    suppl = Chem.SDMolSupplier(os.path.join(raw_dir, "gdb9.sdf"), removeHs=False, sanitize=False)

    out = dict(x=[], pos=[], bonds=[], heavy=[], charge=[], y=[], names=[])
    n_fallback = 0
    for i, mol in enumerate(suppl):
        if mol is None or i in skip or i >= len(rows):
            continue
        if limit is not None and len(out["x"]) >= limit:
            break
        row = rows[i]
        name = mol.GetProp("_Name").strip()
        if name != row["mol_id"].strip():
            raise RuntimeError(f"sdf/csv misalignment at {i}: {name} vs {row['mol_id']}")
        n_fallback += 0 if _sanitize(mol) else 1

        n = mol.GetNumAtoms()
        donor = np.zeros(n, np.float32); acceptor = np.zeros(n, np.float32)
        for f in factory.GetFeaturesForMol(mol):
            tgt = donor if f.GetFamily() == "Donor" else acceptor if f.GetFamily() == "Acceptor" else None
            if tgt is not None:
                for a in f.GetAtomIds():
                    tgt[a] = 1.0
        x = np.zeros((n, N_ATOM_FEATURES), np.float32)
        for a in mol.GetAtoms():
            k = a.GetIdx(); z = a.GetAtomicNum()
            if z not in ATOM_TYPES:
                raise ValueError(f"unexpected element Z={z} in {name}")
            hyb = a.GetHybridization()
            x[k, ATOM_TYPES.index(z)] = 1.0                    # atom type one-hot
            x[k, 5] = z                                        # atomic number
            x[k, 6] = acceptor[k]; x[k, 7] = donor[k]          # acceptor / donor
            x[k, 8] = float(a.GetIsAromatic())                 # aromatic
            x[k, 9] = float(hyb == HT.SP)                      # hybridization (null => 0,0,0)
            x[k, 10] = float(hyb == HT.SP2)
            x[k, 11] = float(hyb == HT.SP3)
            x[k, 12] = a.GetTotalNumHs(includeNeighbors=True)  # number of hydrogens
        pos = mol.GetConformer().GetPositions().astype(np.float32)
        bonds = np.zeros((n, n), np.int8)
        for b in mol.GetBonds():
            u, v = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            bonds[u, v] = bonds[v, u] = bond_map.get(b.GetBondType(), 1)

        g = lambda k: float(row[k])
        y = np.full(len(TARGETS), np.nan, np.float32)
        y[:12] = [g("mu"), g("alpha"), g("homo") * HAR2EV, g("lumo") * HAR2EV,
                  g("gap") * HAR2EV, g("r2"), g("zpve") * HAR2EV,
                  g("u0_atom") * KCALMOL2EV, g("u298_atom") * KCALMOL2EV,   # atomisation
                  g("h298_atom") * KCALMOL2EV, g("g298_atom") * KCALMOL2EV, # energies (eV)
                  g("cv")]
        charge = np.zeros(n, np.float32)
        if xyz_dir is not None:
            p = os.path.join(xyz_dir, f"dsgdb9nsd_{i + 1:06d}.xyz")
            elems, coords, q, freqs = _parse_xyz(p)
            assert len(elems) == n, f"atom count mismatch sdf/xyz for {name}"
            assert np.abs(coords - pos).max() < 5e-2, f"geometry mismatch sdf/xyz for {name}"
            charge = q; y[12] = max(freqs)
        out["x"].append(x); out["pos"].append(pos); out["bonds"].append(bonds)
        out["heavy"].append(np.array([a.GetAtomicNum() > 1 for a in mol.GetAtoms()]))
        out["charge"].append(charge); out["y"].append(y); out["names"].append(name)

    out["y"] = np.stack(out["y"])
    out["has_xyz"] = xyz_dir is not None
    torch.save(out, out_path)
    if verbose:
        print(f"Saved {len(out['x'])} molecules to {out_path} "
              f"({n_fallback} needed partial sanitisation; "
              f"omega1/partial-charge available: {out['has_xyz']})")
    return out


def load_processed(root: str, xyz_dir: Optional[str] = None, download: bool = True):
    """Load cached QM9, building it first if necessary."""
    path = os.path.join(root, "processed.pt")
    if not os.path.exists(path):
        raw = os.path.join(root, "raw")
        if download:
            download_qm9(raw)
        preprocess(raw, path, xyz_dir=xyz_dir)
    return torch.load(path, weights_only=False)


# ---------------------------------------------------------------------------
# Split / normalisation (Sec. 7)
# ---------------------------------------------------------------------------
def make_split(n: int, n_val: int, n_test: int, seed: int = 0):
    """Random split: n_val validation, n_test test, remainder train."""
    perm = np.random.RandomState(seed).permutation(n)
    return perm[n_val + n_test:], perm[:n_val], perm[n_val:n_val + n_test]


class Normalizer:
    """Per-target standardisation to mean 0 / variance 1 (fit on train only)."""
    def __init__(self, mean, std):
        self.mean = np.asarray(mean, np.float32); self.std = np.asarray(std, np.float32)

    @classmethod
    def fit(cls, y):
        return cls(y.mean(0), y.std(0) + 1e-8)

    def __call__(self, y):        # works on numpy or torch (torch path used in training)
        if torch.is_tensor(y):
            return (y - torch.as_tensor(self.mean, device=y.device)) / torch.as_tensor(self.std, device=y.device)
        return (y - self.mean) / self.std

    def inverse(self, y):
        return y * self.std + self.mean


# ---------------------------------------------------------------------------
# Dataset + collate
# ---------------------------------------------------------------------------
class MolDataset(Dataset):
    def __init__(self, data: dict, indices, target_idx, explicit_h: bool = True,
                 use_partial_charge: bool = False):
        self.d, self.idx = data, np.asarray(indices)
        self.t = list(target_idx)
        self.explicit_h, self.use_charge = explicit_h, use_partial_charge
        if use_partial_charge and not data.get("has_xyz", False):
            raise ValueError("partial charge needs preprocessing with --xyz_dir")

    def __len__(self):
        return len(self.idx)

    def __getitem__(self, k):
        j = int(self.idx[k]); d = self.d
        x, pos, bonds = d["x"][j], d["pos"][j], d["bonds"][j]
        if self.use_charge:
            x = np.concatenate([x, d["charge"][j][:, None]], 1)
        if not self.explicit_h:                      # drop H nodes (H count stays a feature)
            keep = d["heavy"][j]
            x, pos, bonds = x[keep], pos[keep], bonds[keep][:, keep]
        return x, pos, bonds, d["y"][j][self.t]


def make_collate(edge_mode: str):
    def collate(items):
        B = len(items); N = max(len(it[0]) for it in items); Fd = items[0][0].shape[1]
        x = torch.zeros(B, N, Fd); pos = torch.zeros(B, N, 3)
        bonds = torch.zeros(B, N, N, dtype=torch.long); mask = torch.zeros(B, N, dtype=torch.bool)
        for i, (xi, pi, bi, _) in enumerate(items):
            n = len(xi)
            x[i, :n] = torch.from_numpy(xi); pos[i, :n] = torch.from_numpy(pi)
            bonds[i, :n, :n] = torch.from_numpy(bi.astype(np.int64)); mask[i, :n] = True
        y = torch.from_numpy(np.stack([it[3] for it in items]).astype(np.float32))
        e = build_edges(pos, bonds, mask, edge_mode)
        return Batch(x, mask, e["edge_mask"], e["edge_label"], e["edge_attr"], y)
    return collate


def make_loader(dataset, edge_mode, batch_size, shuffle, num_workers=0, drop_last=False):
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, drop_last=drop_last,
                      num_workers=num_workers, collate_fn=make_collate(edge_mode))
