"""Download QM9 (sdf + csv + uncharacterized list) and build data/qm9/processed.pt.

    python scripts/prepare_qm9.py                       # 12 of 13 targets (no omega1)
    python scripts/prepare_qm9.py --xyz_dir path/to/xyz # + omega1 and partial charges

omega1 (highest vibrational frequency) and Mulliken charges are NOT in the sdf/csv; they live in
the raw dsgdb9nsd_XXXXXX.xyz files (figshare: https://doi.org/10.6084/m9.figshare.978904).
If the automatic download is blocked, put gdb9.sdf, gdb9.sdf.csv and uncharacterized.txt into
<root>/raw/ by hand and re-run.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from mpnn.data import download_qm9, preprocess  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--root", default="data/qm9")
ap.add_argument("--xyz_dir", default=None)
ap.add_argument("--no_download", action="store_true")
a = ap.parse_args()
raw = os.path.join(a.root, "raw")
if not a.no_download:
    download_qm9(raw)
preprocess(raw, os.path.join(a.root, "processed.pt"), xyz_dir=a.xyz_dir)
