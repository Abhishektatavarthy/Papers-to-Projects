#!/usr/bin/env bash
# Reproduce the paper's experiments.  Every command is scalable via STEPS / TRIALS.
# Full paper protocol:  STEPS=3000000 TRIALS=50   (weeks of GPU time for all 13 targets!)
# Quick look:           STEPS=20000   TRIALS=2
set -euo pipefail
STEPS=${STEPS:-3000000}; TRIALS=${TRIALS:-50}; COMMON="--steps $STEPS --trials $TRIALS"

# ---- Table 2: best model (edge network + set2set), explicit H, raw distances; 13 targets
python -m mpnn.hparam_search --preset enn-s2s --targets all $COMMON --out_dir runs/enn-s2s
python -m mpnn.ensemble --runs runs/enn-s2s --targets all --top_k 5          # single + ens5 columns

# ---- Table 2 baseline: GG-NN with distance bins
python -m mpnn.hparam_search --preset ggnn-bins --targets all $COMMON --out_dir runs/ggnn-bins

# ---- Table 3: no spatial information (partial-charge feature was used in the paper; needs --xyz_dir data)
for P in nospatial-ggnn nospatial-virtual nospatial-master nospatial-s2s; do
  python -m mpnn.hparam_search --preset $P --targets all $COMMON --use_partial_charge --out_dir runs/$P
done

# ---- Table 4: towers vs vanilla GG-NN (individual training; add --targets ... for joint training)
for P in ggnn-s2s-bins towers8-s2s-bins; do
  python -m mpnn.hparam_search --preset $P --targets all $COMMON --hidden_dims 200 --out_dir runs/$P
done

# ---- Sec 8 additional experiment: pair message
python -m mpnn.hparam_search --preset pair-s2s --targets all $COMMON --out_dir runs/pair-s2s
