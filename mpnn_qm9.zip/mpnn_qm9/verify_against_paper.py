"""Programmatic cross-check of this implementation against Gilmer et al. (2017).

Run:  python verify_against_paper.py
Exit code 0 only if every hard check passes.  Informational items (timings, things the
paper does not specify) are printed but never fail the run.

Two kinds of evidence:
  (A) numerical: independent, deliberately naive per-node re-implementations of the paper's
      equations (1)-(4) and set2set are compared with the vectorised model;
  (B) constants: every number the paper states (bins, alphabet size, ranges, epochs, table
      averages, ...) is compared with what the code uses.
"""
import statistics
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

from mpnn import constants as C
from mpnn.data import (DIST_BOUNDARIES, EDGE_MODES, MolDataset, build_edges, make_collate,
                       node_feature_dim)
from mpnn.hparam_search import sample_config
from mpnn.model import MPNN, MPNNConfig
from mpnn.synthetic import make_synthetic
from mpnn.train import TrainConfig, lr_multiplier

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  -- {detail}" if detail else ""))


torch.manual_seed(0)
DATA = make_synthetic(30, max_atoms=9, seed=3)


LARGEST = int(np.argmax([len(x) for x in DATA["x"]]))     # most atoms -> hardest case for the loops


def one_mol_batch(mode, idx=None):
    ds = MolDataset(DATA, [LARGEST if idx is None else idx], [0])
    return make_collate(mode)([ds[0]])


# ------------------------------------------------------------------ (A1) eqs (1)-(3)
print("\n(A1) Eqs. (1)-(3): naive per-node loops vs vectorised model")


def naive_forward(model, b):
    """Literal transcription of the paper: m_v = sum_{w in N(v)} M(h_v,h_w,e_vw); h_v = GRU(h_v,m_v)."""
    tw = model.towers[0]; msg = tw.message
    d = model.cfg.hidden_dim
    n = int(b.node_mask.sum())
    ef = b.edge_features(model.n_labels)[0]; em = b.edge_mask[0]; lab = None if b.edge_label is None else b.edge_label[0]
    h0 = F.pad(b.x[0], (0, d - b.x.shape[-1])); h = h0.clone()

    def M(m_fn, v, w, hh):                       # one message M(h_v, h_w, e_vw)
        if model.cfg.message == "edge_network":
            A = m_fn.net(ef[v, w]).view(d, d)
            return A @ hh[w]
        if model.cfg.message == "matrix":
            return m_fn.A[lab[v, w]] @ hh[w]     # A_{e_vw} h_w  (GG-NN)
        return m_fn.net(torch.cat([hh[v], hh[w], ef[v, w]]))     # pair message

    for _ in range(model.cfg.mp_steps):
        new = []
        for v in range(n):
            nbrs = [w for w in range(n) if em[v, w]]
            m_in = sum((M(msg.m_in, v, w, h) for w in nbrs), torch.zeros(d))
            m_out = sum((M(msg.m_out, v, w, h) for w in nbrs), torch.zeros(d))
            m_v = torch.cat([m_in, m_out])                                   # eq (1), 2d channel
            new.append(tw.gru(m_v[None], h[v][None])[0])                     # eq (2)
        h = torch.stack(new)
    return model.readout(h[None], h0[None], b.x, b.node_mask)               # eq (3)


for message, mode in [("edge_network", "raw_distance"), ("matrix", "distance_bins"), ("pair", "raw_distance")]:
    for readout in ("set2set", "ggnn"):
        cfg = MPNNConfig(hidden_dim=24, mp_steps=3, message=message, readout=readout, s2s_steps=3,
                         readout_dim=16, edge_hidden=16)
        model = MPNN(cfg, node_feature_dim(), mode).eval()
        b = one_mol_batch(mode)
        with torch.no_grad():
            err = (model(b) - naive_forward(model, b)).abs().max().item()
        with torch.no_grad():
            before = model(b).clone()
            for p_ in model.towers[0].message.parameters():
                p_.add_(0.3 * torch.randn_like(p_))
            sens = (model(b) - before).abs().max().item()
            assert (model(b) - naive_forward(model, b)).abs().max().item() < 1e-4   # still equal after perturbation
        check(f"eq.1-3 vectorised == naive loops  [{message:12s} + {readout:7s}]", err < 1e-4 and sens > 1e-4,
              f"max|diff|={err:.1e} on {int(b.node_mask.sum())} atoms; output moves {sens:.1e} if message weights change")

# ------------------------------------------------------------------ (A2) set2set
print("\n(A2) Set2set (Sec 5.3) vs literal algorithm, on a padded batch")
cfg = MPNNConfig(hidden_dim=24, mp_steps=2, readout="set2set", s2s_steps=4, readout_dim=16, edge_hidden=16)
model = MPNN(cfg, node_feature_dim(), "raw_distance").eval()
ds = MolDataset(DATA, [0, 1, 2, 3], [0])
b = make_collate("raw_distance")([ds[i] for i in range(4)])
s2s = model.readout
with torch.no_grad():
    hT = torch.randn(4, b.x.shape[1], 24)
    out = s2s(hT, None, b.x, b.node_mask)
    ok = True
    for i in range(4):
        n = int(b.node_mask[i].sum())
        m = s2s.proj(torch.cat([hT[i, :n], b.x[i, :n]], -1))
        qs = torch.zeros(1, 32); hh = torch.zeros(1, 16); cc = torch.zeros(1, 16)
        for _ in range(4):
            hh, cc = s2s.lstm(qs, (hh, cc))
            a = torch.softmax(m @ hh[0], 0)
            qs = torch.cat([hh[0], a @ m])[None]
        ok &= torch.allclose(s2s.head(qs)[0], out[i], atol=1e-5)
check("set2set (proj of (h_T,x_v), LSTM q_t, softmax attention, q*=[q,r]) matches, padding ignored", ok)

# ------------------------------------------------------------------ (A3) invariance
print("\n(A3) Invariance to graph isomorphism (Sec 2: R must be permutation invariant)")
m = MPNN(MPNNConfig(hidden_dim=24, mp_steps=3, s2s_steps=3, readout_dim=16, edge_hidden=16),
         node_feature_dim(), "raw_distance").eval()
x, pos, bonds, _ = MolDataset(DATA, [LARGEST], [0])[0]
perm = np.random.RandomState(1).permutation(len(x))
coll = make_collate("raw_distance"); z = np.zeros(1, np.float32)
with torch.no_grad():
    d_ = (m(coll([(x, pos, bonds, z)])) - m(coll([(x[perm], pos[perm], bonds[perm][:, perm], z)]))).abs().max().item()
check("enn-s2s output unchanged under random atom relabelling", d_ < 1e-4, f"max|diff|={d_:.1e}")

# ------------------------------------------------------------------ (B) stated constants
print("\n(B) Constants and design details stated in the paper")
check("Table 1: 13 atom features (type5 + Z + acc + don + arom + hyb3 + numH)", C.N_ATOM_FEATURES == 13
      and C.ATOM_FEATURE_NAMES[:5] == ["type_H", "type_C", "type_N", "type_O", "type_F"])
check("atoms limited to H,C,N,O,F", C.ATOM_TYPES == (1, 6, 7, 8, 9))
check("distance bins: 8 uniform on [2,6] + [0,2] + [6,inf) = 10", len(DIST_BOUNDARIES) == 9 and C.N_DIST_BINS == 10
      and float(DIST_BOUNDARIES[0]) == 2.0 and float(DIST_BOUNDARIES[-1]) == 6.0)
check("edge alphabet for distance-bin adjacency = 14", EDGE_MODES["distance_bins"]["n_labels"] == 14)
check("raw distance edge feature is 5-dim (distance + 4 one-hot bond type)", EDGE_MODES["raw_distance"]["edge_dim"] == 5)
check("chemical graph edge alphabet: single/double/triple/aromatic = 4", EDGE_MODES["chemical"]["n_labels"] == 4)
b_ = one_mol_batch("raw_distance")
check("undirected graph -> directed with 2d message channel (Sec 5)",
      MPNN(MPNNConfig(hidden_dim=32), 13, "raw_distance").towers[0].msg_dim == 64)
check("GRU update with tied weights: single GRU cell reused for all T steps",
      sum(isinstance(mm, torch.nn.GRUCell) for mm in MPNN(MPNNConfig(mp_steps=8), 13, "raw_distance").modules()) == 1)
check("batch size 20, 3M steps (Sec 7)", C.PAPER_BATCH_SIZE == 20 and C.PAPER_STEPS == 3_000_000 and TrainConfig().batch_size == 20)
epochs = 3_000_000 * 20 / (130462 - 20000)
check("3M steps x 20 / 110,462 train molecules ~= paper's '~540 epochs'", abs(epochs - 540) < 10, f"{epochs:.0f} epochs")
check("10k validation / 10k test split", (C.PAPER_N_VAL, C.PAPER_N_TEST) == (10_000, 10_000))
check("ranges: T in [3,8], M in [1,12], LR in [1e-5,5e-4], F in [.01,1], decay start 10-90%",
      C.PAPER_T_RANGE == (3, 8) and C.PAPER_S2S_RANGE == (1, 12) and C.PAPER_LR_RANGE == (1e-5, 5e-4)
      and C.PAPER_DECAY_FACTOR_RANGE == (0.01, 1.0) and C.PAPER_DECAY_START_RANGE == (0.1, 0.9))
rng = np.random.RandomState(0)
cfgs = [sample_config(TrainConfig(), rng, [64]) for _ in range(300)]
check("hparam sampler stays inside the paper's ranges (300 draws)",
      all(3 <= c.model.mp_steps <= 8 and 1 <= c.model.s2s_steps <= 12 and 1e-5 <= c.lr <= 5e-4
          and 0.1 <= c.decay_start <= 0.9 and 0.01 <= c.decay_factor <= 1.0 for c in cfgs))
check("50 trials per model/target, ensemble of top 5 by validation", C.PAPER_N_TRIALS == 50 and C.PAPER_ENSEMBLE_K == 5)
check("LR schedule: constant, then linear decay to l*F",
      lr_multiplier(10, 100, .5, .1) == 1.0 and abs(lr_multiplier(100, 100, .5, .1) - .1) < 1e-12)
check("13 targets in Table-2 order", len(C.TARGETS) == 13 and C.TARGETS[0] == "mu" and C.TARGETS[-1] == "omega1")

# transcription checks on the paper's Table 2 numbers that are stored for comparison reports
check("Table 2 transcription: enn-s2s column averages to the paper's 0.68",
      abs(np.mean(list(C.PAPER_ENN_S2S.values())) - 0.68) < 0.006, f"{np.mean(list(C.PAPER_ENN_S2S.values())):.3f}")
check("Table 2 transcription: ens5 column averages to the paper's 0.52",
      abs(np.mean(list(C.PAPER_ENN_S2S_ENS5.values())) - 0.52) < 0.006, f"{np.mean(list(C.PAPER_ENN_S2S_ENS5.values())):.3f}")
check("Table 2 transcription: chemical accuracy on 11/13 targets (ratio<1) for enn-s2s",
      sum(v < 1 for v in C.PAPER_ENN_S2S.values()) == 11)
check("Table 2 transcription: only gap and ZPVE above 1 (the 'all but two targets')",
      sorted(k for k, v in C.PAPER_ENN_S2S.items() if v >= 1) == ["gap", "zpve"])

# ------------------------------------------------------------------ (C) towers
print("\n(C) Towers (Sec 5.4)")
def n_params(k):
    cfg = MPNNConfig(hidden_dim=200, message="matrix", readout="ggnn", towers=k)
    return sum(p.numel() for p in MPNN(cfg, 13, "distance_bins").towers.parameters())
p1, p8 = n_params(1), n_params(8)
check("message+GRU parameters shrink ~k-fold with k towers of size d/k", p8 < p1 / 5, f"k=1: {p1:,}  k=8: {p8:,}  ({p1 / p8:.1f}x fewer)")

torch.set_num_threads(1)
def bench(k, n=9, d=200, B=100, reps=7):
    cfg = MPNNConfig(hidden_dim=d, mp_steps=6, message="matrix", readout="ggnn", towers=k)
    model = MPNN(cfg, 13, "distance_bins").eval()
    pos = torch.rand(B, n, 3) * 5; bonds = torch.zeros(B, n, n, dtype=torch.long)
    mask = torch.ones(B, n, dtype=torch.bool); e = build_edges(pos, bonds, mask, "distance_bins")
    from mpnn.data import Batch
    bt = Batch(torch.rand(B, n, 13), mask, e["edge_mask"], e["edge_label"], None)
    ts = []
    with torch.no_grad():
        model(bt)
        for _ in range(reps):
            t = time.perf_counter(); model(bt); ts.append(time.perf_counter() - t)
    return statistics.median(ts)
t1, t8 = bench(1), bench(8)
print(f"  [INFO] inference time, n=9, d=200, CPU 1 thread: k=1 {t1 * 1e3:.0f} ms, k=8 {t8 * 1e3:.0f} ms "
      f"-> speed-up x{t1 / t8:.2f}   (paper reports ~2x with its implementation)")

# ------------------------------------------------------------------ summary
n_fail = sum(not ok for _, ok in RESULTS)
print(f"\n{len(RESULTS) - n_fail}/{len(RESULTS)} hard checks passed")
sys.exit(1 if n_fail else 0)
