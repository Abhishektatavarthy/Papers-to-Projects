import json
import os

import numpy as np
import pytest

from mpnn.constants import PAPER_BATCH_SIZE, PAPER_STEPS
from mpnn.data import Normalizer, make_split
from mpnn.model import MPNNConfig
from mpnn.train import TrainConfig, build_parser, config_from_args, lr_multiplier, run


def test_lr_schedule_shape():
    T, s, F = 1000, 0.4, 0.05
    assert lr_multiplier(1, T, s, F) == 1.0 and lr_multiplier(400, T, s, F) == 1.0   # constant phase
    assert abs(lr_multiplier(700, T, s, F) - (1 + (F - 1) * 0.5)) < 1e-9            # linear midpoint
    assert abs(lr_multiplier(T, T, s, F) - F) < 1e-9                                 # ends at l * F


def test_split_is_disjoint_and_sized():
    tr, va, te = make_split(1000, 100, 100, seed=3)
    assert len(tr) == 800 and len(va) == 100 and len(te) == 100
    assert len(set(tr) | set(va) | set(te)) == 1000
    assert (make_split(1000, 100, 100, seed=3)[1] == va).all()                       # deterministic


def test_normalizer_roundtrip_and_stats():
    y = np.random.RandomState(0).normal(5, 3, size=(500, 2)).astype(np.float32)
    n = Normalizer.fit(y)
    z = n(y)
    assert np.allclose(z.mean(0), 0, atol=1e-4) and np.allclose(z.std(0), 1, atol=1e-3)
    assert np.allclose(n.inverse(z), y, atol=1e-4)


def test_default_config_matches_paper_protocol():
    c = TrainConfig()
    assert c.batch_size == PAPER_BATCH_SIZE == 20 and c.steps == PAPER_STEPS == 3_000_000


@pytest.mark.parametrize("preset", ["enn-s2s", "ggnn-bins", "towers8-s2s-bins", "nospatial-master"])
def test_end_to_end_smoke_and_learning(preset, tmp_path):
    args = build_parser().parse_args(
        ["--preset", preset, "--targets", "mu", "--synthetic", "300", "--n_val", "40", "--n_test", "40",
         "--steps", "120", "--eval_every", "60", "--log_every", "60", "--lr", "1e-3",
         "--hidden_dim", "64", "--out_dir", str(tmp_path)])
    cfg = config_from_args(args)
    cfg.model.mp_steps = 3; cfg.model.s2s_steps = 2; cfg.model.readout_dim = 32; cfg.model.edge_hidden = 32
    m = run(cfg)
    assert os.path.exists(tmp_path / "results.npz") and os.path.exists(tmp_path / "best.pt")
    assert np.isfinite(m["test_ratio_mean"])
    first, last = m["train_log"][0]["val_error_ratio"], m["train_log"][-1]["val_error_ratio"]
    assert min(first, last) <= first                                                  # model selection works


def test_nan_target_is_rejected(tmp_path):
    from mpnn.synthetic import make_synthetic
    d = make_synthetic(60); d["y"][:, 12] = np.nan
    cfg = TrainConfig(targets=("omega1",), out_dir=str(tmp_path), steps=2, n_val=10, n_test=10)
    with pytest.raises(ValueError, match="NaN"):
        run(cfg, data=d)
