import itertools

import numpy as np
import pytest
import torch

from mpnn.constants import N_DISTANCE_BIN_LABELS
from mpnn.data import (DIST_BOUNDARIES, EDGE_MODES, MolDataset, build_edges, make_collate,
                       node_feature_dim)
from mpnn.model import MPNN, MPNNConfig, count_parameters
from mpnn.synthetic import make_synthetic

DATA = make_synthetic(n_mols=40, max_atoms=10, seed=1)


def batch_of(idx, mode, explicit_h=True, charge=False):
    ds = MolDataset(DATA, idx, [0, 1], explicit_h=explicit_h, use_partial_charge=charge)
    return make_collate(mode)([ds[i] for i in range(len(ds))])


# (message, edge_mode) pairs that are legal
COMBOS = [("edge_network", "raw_distance"), ("edge_network", "distance_bins"),
          ("matrix", "chemical"), ("matrix", "chemical_virtual"), ("matrix", "distance_bins"),
          ("pair", "raw_distance"), ("pair", "chemical")]


@pytest.mark.parametrize("message,mode", COMBOS)
@pytest.mark.parametrize("readout", ["set2set", "ggnn"])
def test_output_shape_and_grad(message, mode, readout):
    cfg = MPNNConfig(hidden_dim=32, mp_steps=3, message=message, readout=readout, s2s_steps=2,
                     readout_dim=16, edge_hidden=16)
    m = MPNN(cfg, node_feature_dim(), mode, n_out=2)
    b = batch_of([0, 1, 2, 3], mode)
    out = m(b)
    assert out.shape == (4, 2)
    out.sum().backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in m.parameters()
               if p.requires_grad)


@pytest.mark.parametrize("towers,master", [(1, False), (4, False), (1, True)])
@pytest.mark.parametrize("message,mode", [("edge_network", "raw_distance"), ("matrix", "chemical")])
@pytest.mark.parametrize("readout", ["set2set", "ggnn"])
def test_permutation_invariance(message, mode, readout, towers, master):
    """Core MPNN property: output is invariant to graph isomorphism (atom relabelling)."""
    torch.manual_seed(0)
    cfg = MPNNConfig(hidden_dim=32, mp_steps=3, message=message, readout=readout, s2s_steps=3,
                     readout_dim=16, edge_hidden=16, towers=towers, master=master, master_dim=8)
    m = MPNN(cfg, node_feature_dim(), mode).eval()
    x, pos, bonds, _ = MolDataset(DATA, [5], [0])[0]
    perm = np.random.RandomState(0).permutation(len(x))
    coll = make_collate(mode)
    b1 = coll([(x, pos, bonds, np.zeros(1, np.float32))])
    b2 = coll([(x[perm], pos[perm], bonds[perm][:, perm], np.zeros(1, np.float32))])
    with torch.no_grad():
        assert torch.allclose(m(b1), m(b2), atol=1e-4, rtol=1e-4)


@pytest.mark.parametrize("message,mode", [("edge_network", "raw_distance"), ("matrix", "distance_bins")])
def test_padding_invariance(message, mode):
    """A molecule's prediction must not depend on what it is padded/batched with."""
    torch.manual_seed(0)
    cfg = MPNNConfig(hidden_dim=32, mp_steps=4, message=message, s2s_steps=3, readout_dim=16, edge_hidden=16)
    m = MPNN(cfg, node_feature_dim(), mode).eval()
    lens = [len(DATA["x"][i]) for i in range(10)]
    small, big = int(np.argmin(lens)), int(np.argmax(lens))
    assert lens[small] < lens[big]
    with torch.no_grad():
        alone = m(batch_of([small], mode))
        padded = m(batch_of([small, big], mode))[:1]
    assert torch.allclose(alone, padded, atol=1e-4, rtol=1e-4)


def test_distance_bins_match_paper():
    # 8 uniform bins on [2,6] + [0,2] + [6,inf) = 10 bins; alphabet 4 bond + 10 = 14
    assert len(DIST_BOUNDARIES) == 9 and DIST_BOUNDARIES[0] == 2.0 and DIST_BOUNDARIES[-1] == 6.0
    assert N_DISTANCE_BIN_LABELS == 14 and EDGE_MODES["distance_bins"]["n_labels"] == 14
    pos = torch.zeros(1, 6, 3)
    pos[0, :, 0] = torch.tensor([0.0, 1.0, 2.5, 4.1, 5.9, 7.0])       # distances from atom 0
    bonds = torch.zeros(1, 6, 6, dtype=torch.long)
    e = build_edges(pos, bonds, torch.ones(1, 6, dtype=torch.bool), "distance_bins")
    labels = e["edge_label"][0, 0, 1:] - 4                             # bin ids
    assert labels.tolist() == [0, 2, 5, 8, 9]   # bin0=<2, bin1=[2,2.5), bin2=[2.5,3) ... bin5=[4,4.5), bin8=[5.5,6), bin9=>=6
    assert e["edge_label"].max() <= 13


def test_bonded_pairs_use_bond_type_label():
    pos = torch.rand(1, 3, 3) * 3
    bonds = torch.zeros(1, 3, 3, dtype=torch.long); bonds[0, 0, 1] = bonds[0, 1, 0] = 4  # aromatic
    e = build_edges(pos, bonds, torch.ones(1, 3, dtype=torch.bool), "distance_bins")
    assert e["edge_label"][0, 0, 1] == 3 and e["edge_label"][0, 1, 0] == 3


def test_raw_distance_is_5d_and_diag_masked():
    b = batch_of([0, 1], "raw_distance")
    assert b.edge_attr.shape[-1] == 5
    assert not b.edge_mask.diagonal(dim1=1, dim2=2).any()             # no self-loops
    # one-hot part is all-zero for non-bonded pairs, one-hot for bonded pairs
    oh = b.edge_attr[..., 1:]
    assert ((oh.sum(-1) == 0) | (oh.sum(-1) == 1)).all()


def test_chemical_graph_is_sparse_and_virtual_edges_are_dense():
    bc = batch_of([0, 1, 2], "chemical"); bv = batch_of([0, 1, 2], "chemical_virtual")
    assert bc.edge_mask.sum() < bv.edge_mask.sum()
    assert bv.edge_label.max() == 4                                    # virtual edge type present


def test_explicit_hydrogens_add_nodes_and_charge_adds_feature():
    n_all = batch_of([0, 1, 2, 3], "chemical", explicit_h=True).node_mask.sum()
    n_heavy = batch_of([0, 1, 2, 3], "chemical", explicit_h=False).node_mask.sum()
    assert n_all > n_heavy
    assert batch_of([0], "chemical", charge=True).x.shape[-1] == 14


def test_message_channel_is_2d_when_directed():
    cfg = MPNNConfig(hidden_dim=32, message="edge_network", directed=True)
    assert MPNN(cfg, 13, "raw_distance").towers[0].msg_dim == 64
    cfg = MPNNConfig(hidden_dim=32, message="edge_network", directed=False)
    assert MPNN(cfg, 13, "raw_distance").towers[0].msg_dim == 32


def test_towers_reduce_parameters_by_about_k():
    """Sec 5.4: k towers of size d/k -> message parameters shrink ~k-fold (d^2/k)."""
    base = MPNNConfig(hidden_dim=64, message="matrix", readout="ggnn", towers=1)
    p1 = sum(p.numel() for p in MPNN(base, 13, "chemical").towers.parameters())
    base.towers = 8
    p8 = sum(p.numel() for p in MPNN(base, 13, "chemical").towers.parameters())
    assert p8 < p1 / 4


def test_invalid_configs_raise():
    with pytest.raises(ValueError):
        MPNN(MPNNConfig(message="matrix"), 13, "raw_distance")        # matrix needs discrete edges
    with pytest.raises(ValueError):
        MPNN(MPNNConfig(hidden_dim=30, towers=4), 13, "chemical")     # d not divisible by k
    with pytest.raises(ValueError):
        MPNN(MPNNConfig(hidden_dim=8), 13, "chemical")                # d < node feature dim
