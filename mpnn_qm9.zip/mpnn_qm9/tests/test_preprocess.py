"""Checks the RDKit featurisation (paper Table 1) on a hand-made mini QM9-format dataset."""
import csv
import os

import numpy as np
import pytest

pytest.importorskip("rdkit")
from rdkit import Chem
from rdkit.Chem import AllChem

from mpnn.constants import ATOM_FEATURE_NAMES, TARGETS
from mpnn.data import MolDataset, make_collate, preprocess

SMILES = ["C", "CC", "c1ccccc1", "CCO", "C=O", "CC#N", "CN", "FC"]
COLS = ["mol_id", "A", "B", "C", "mu", "alpha", "homo", "lumo", "gap", "r2", "zpve", "u0", "u298",
        "h298", "g298", "cv", "u0_atom", "u298_atom", "h298_atom", "g298_atom"]


@pytest.fixture(scope="module")
def processed(tmp_path_factory):
    raw = tmp_path_factory.mktemp("raw")
    w = Chem.SDWriter(str(raw / "gdb9.sdf"))
    rows = []
    for i, s in enumerate(SMILES):
        mol = Chem.AddHs(Chem.MolFromSmiles(s))
        assert AllChem.EmbedMolecule(mol, randomSeed=7) == 0
        mol.SetProp("_Name", f"gdb_{i + 1}")
        w.write(mol)
        rows.append({c: (f"gdb_{i + 1}" if c == "mol_id" else str(0.1 * (i + 1) * (j + 1)))
                     for j, c in enumerate(COLS)})
    w.close()
    with open(raw / "gdb9.sdf.csv", "w", newline="") as f:
        cw = csv.DictWriter(f, COLS); cw.writeheader(); cw.writerows(rows)
    return preprocess(str(raw), str(raw / "processed.pt"), verbose=False)


def feat(data, i, name):
    return data["x"][i][:, ATOM_FEATURE_NAMES.index(name)]


def test_shapes_and_targets(processed):
    d = processed
    assert len(d["x"]) == len(SMILES) and d["x"][0].shape[1] == 13 == len(ATOM_FEATURE_NAMES)
    assert d["y"].shape == (len(SMILES), len(TARGETS)) and np.isnan(d["y"][:, 12]).all()  # omega1 needs xyz
    # methane: 5 atoms (1 C + 4 H), 4 bonds
    assert len(d["x"][0]) == 5 and (d["bonds"][0] > 0).sum() == 8


def test_atom_type_onehot_and_atomic_number(processed):
    x = processed["x"][3]                                    # ethanol C2H6O: 9 atoms
    assert len(x) == 9 and (x[:, :5].sum(1) == 1).all()
    assert feat(processed, 3, "type_C").sum() == 2 and feat(processed, 3, "type_O").sum() == 1
    assert feat(processed, 3, "type_H").sum() == 6
    assert sorted(set(feat(processed, 3, "atomic_number"))) == [1.0, 6.0, 8.0]


def test_aromatic_and_hybridization(processed):
    assert feat(processed, 2, "aromatic").sum() == 6        # benzene carbons
    assert feat(processed, 2, "sp2").sum() == 6
    assert (processed["bonds"][2] == 4).sum() == 12          # 6 aromatic bonds, both directions
    assert feat(processed, 5, "sp").sum() == 2               # acetonitrile: CN carbon & nitrogen are sp
    assert feat(processed, 1, "sp3").sum() == 2              # ethane carbons
    # hydrogens have "null" hybridisation -> all-zero sp/sp2/sp3
    h = feat(processed, 1, "type_H") == 1
    assert (processed["x"][1][h][:, 9:12] == 0).all()


def test_donor_acceptor_and_num_hs(processed):
    # ethanol: O is both donor (O-H) and acceptor
    o = feat(processed, 3, "type_O") == 1
    assert feat(processed, 3, "donor")[o].all() and feat(processed, 3, "acceptor")[o].all()
    assert feat(processed, 3, "num_hydrogens")[o][0] == 1
    c = (feat(processed, 1, "type_C") == 1)
    assert (feat(processed, 1, "num_hydrogens")[c] == 3).all()


def test_units_atomisation_energy_in_ev(processed):
    # csv value 'u0_atom' col index 16 -> 0.1*(i+1)*(17)  [kcal/mol] converted to eV
    expected = 0.1 * 1 * 17 * 0.04336414
    assert abs(processed["y"][0, TARGETS.index("u0")] - expected) < 1e-4


def test_pipeline_produces_batches_in_all_edge_modes(processed):
    for mode in ["chemical", "chemical_virtual", "distance_bins", "raw_distance"]:
        for eh in (True, False):
            ds = MolDataset(processed, range(len(SMILES)), [0, 1], explicit_h=eh)
            b = make_collate(mode)([ds[i] for i in range(len(ds))])
            assert b.x.shape[0] == len(SMILES) and b.y.shape == (len(SMILES), 2)
    # explicit H: benzene has 12 nodes; heavy-only: 6
    assert MolDataset(processed, [2], [0], True)[0][0].shape[0] == 12
    assert MolDataset(processed, [2], [0], False)[0][0].shape[0] == 6


def test_xyz_parsing_gives_omega1_and_partial_charges(tmp_path):
    """omega1 (max vibrational frequency) and Mulliken charges come from the raw .xyz files."""
    raw = tmp_path / "raw"; xyz = tmp_path / "xyz"; raw.mkdir(); xyz.mkdir()
    mol = Chem.AddHs(Chem.MolFromSmiles("C")); AllChem.EmbedMolecule(mol, randomSeed=7)
    mol.SetProp("_Name", "gdb_1")
    w = Chem.SDWriter(str(raw / "gdb9.sdf")); w.write(mol); w.close()
    with open(raw / "gdb9.sdf.csv", "w", newline="") as f:
        cw = csv.DictWriter(f, COLS); cw.writeheader()
        cw.writerow({c: ("gdb_1" if c == "mol_id" else "1.0") for c in COLS})
    pos = mol.GetConformer().GetPositions()
    lines = ["5", "gdb 1\t157.7\t157.7\t157.7\t0.\t13.2"]
    els = [a.GetSymbol() for a in mol.GetAtoms()]
    for k, (e, p) in enumerate(zip(els, pos)):
        lines.append(f"{e}\t{p[0]:.6f}\t{p[1]:.6f}\t{p[2]:.6f}\t{-0.5 if k == 0 else 0.125:.6f}")
    lines += ["1341.307\t1341.3284\t1341.365\t1562.6731\t1562.7453\t3038.3205\t3151.6034\t3151.6788\t3151.7078",
              "C", "C", "InChI=1S/CH4/h1H4"]
    (xyz / "dsgdb9nsd_000001.xyz").write_text("\n".join(lines))
    d = preprocess(str(raw), str(raw / "p.pt"), xyz_dir=str(xyz), verbose=False)
    assert abs(d["y"][0, TARGETS.index("omega1")] - 3151.7078) < 1e-3
    assert abs(d["charge"][0][0] + 0.5) < 1e-6 and d["has_xyz"]
    ds = MolDataset(d, [0], [0], use_partial_charge=True)
    assert ds[0][0].shape[1] == 14                     # 13 Table-1 features + partial charge
