# MPNN for QM9 — implementation of *Neural Message Passing for Quantum Chemistry*

PyTorch implementation of the Message Passing Neural Network framework of Gilmer et al. (2017) and the best model from the paper (**edge network + GRU + set2set**), plus the GG-NN baselines, virtual edges, master node, towers and the training / hyper-parameter-search / ensembling protocol.

### Status

- ✅ **Architecture and training pipeline are implemented and numerically verified** against the paper's equations — see `python verify_against_paper.py` and [`PAPER_VERIFICATION.md`](PAPER_VERIFICATION.md).
- ⚠️ **The paper's reported benchmark results (Table 2/3/4) have not been reproduced.** That requires training on the full QM9 dataset with real GPU compute, which has not been run yet. Everything needed to do so is here (`scripts/prepare_qm9.py`, `scripts/run_paper_experiments.sh`) — contributions/runs welcome.
- No data, checkpoints, or results are bundled in this repo — source code only.

## Setup
```bash
pip install -r requirements.txt
python scripts/prepare_qm9.py                        # downloads QM9, featurises (RDKit) -> data/qm9/processed.pt
python scripts/prepare_qm9.py --xyz_dir /path/xyz    # optional: also gets omega1 + partial charges
python verify_against_paper.py                       # equation-level checks against the paper
pytest tests                                         # 52 tests
```

## Train one model (paper protocol: one model per target)
```bash
python -m mpnn.train --preset enn-s2s --targets u0 --out_dir runs/u0        # 3M steps, batch 20, like the paper
python -m mpnn.train --preset enn-s2s --targets u0 --steps 50000 --lr 3e-4   # quick run
python -m mpnn.train --preset enn-s2s --targets all                          # joint training (paper: worse)
python -m mpnn.train --preset enn-s2s --synthetic 500 --steps 200            # offline smoke test
```
Any `MPNNConfig` / `TrainConfig` field is a flag (`--hidden_dim 128 --mp_steps 6 --s2s_steps 8 --towers 8 --master true --message matrix ...`).
Note `--steps` = optimiser steps, `--mp_steps` = T (message-passing rounds).

## Full protocol (search → ensemble → Table 2)
```bash
python -m mpnn.hparam_search --preset enn-s2s --targets all --trials 50 --out_dir runs/enn-s2s
python -m mpnn.ensemble --runs runs/enn-s2s --targets all --top_k 5
```
`scripts/run_paper_experiments.sh` runs Tables 2, 3, 4 and the pair-message comparison (scale down with `STEPS=… TRIALS=…`).

## Presets (`mpnn/presets.py`)
| preset | paper | message | readout | edges | explicit H |
|---|---|---|---|---|---|
| `enn-s2s` | Table 2 best | edge network | set2set | raw distance + bond type | yes |
| `ggnn-bins` | Table 2 GG-NN | matrix | GG-NN (eq. 4) | distance bins | no |
| `nospatial-{ggnn,virtual,master,s2s}` | Table 3 | matrix | GG-NN / set2set | chemical graph (+virtual edges / master node) | no |
| `ggnn-s2s-bins`, `towers8-s2s-bins` | Table 4 | matrix (×8 towers) | set2set | distance bins | no |
| `pair-s2s` | Sec. 8 | pair | set2set | raw distance | yes |

## Layout
```
mpnn/constants.py     targets, chemical accuracy, paper ranges/tables
mpnn/data.py          QM9 preprocessing (Table 1 features), split, normaliser, edge representations, dense batching
mpnn/layers.py        message functions, GRU tower, GG-NN readout, set2set
mpnn/model.py         MPNN: eqs. 1-3, towers (eq. 5), master node
mpnn/train.py         training loop, LR schedule, model selection, error ratios
mpnn/hparam_search.py 50-trial random search (paper ranges)
mpnn/ensemble.py      top-5-by-validation ensembling + Table-2 style report
mpnn/synthetic.py     tiny fake QM9 for offline tests
verify_against_paper.py, PAPER_VERIFICATION.md, tests/, scripts/
```

## Practical notes
* **Memory/speed.** The edge network materialises a `[B,N,N,d,d]` matrix tensor per channel (in/out), computed once per forward and reused over all T steps. Measured on CPU (fwd+bwd, B=5, N=29, d=64) and extrapolated linearly: **≈3 GB peak for B=20, N=29, d=64**; memory grows ∝ d², so d=128 needs ≈4× that. Use a GPU, or lower `--hidden_dim` / batch size. Explicit hydrogens cost ~10× more than heavy-atom graphs (as the paper notes).
* **Compute.** The paper protocol (3M steps × 50 trials × 13 targets) is very large; use `--steps`/`--trials` to scale down.
* **Values to double-check** before quoting error ratios: `CHEMICAL_ACCURACY` in `mpnn/constants.py` (from the paper's supplementary, not in the PDF this was built from).
