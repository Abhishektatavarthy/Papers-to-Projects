import numpy as np
from qh9.dft import build_mol, verify_ao_layout, run_dft, overlap
from qh9.orbitals import ao_real_sh
from pyscf import gto

WATER = ([8, 1, 1], [[0, 0, .117], [0, .757, -.469], [0, -.757, -.469]])


def test_ao_layout_matches_pyscf():
    Z, pos = WATER
    verify_ao_layout(build_mol(Z, pos), Z)
    Z2 = [6, 7, 8, 9, 1, 1]; p2 = np.random.default_rng(0).normal(size=(6, 3)) * 1.5
    verify_ao_layout(build_mol(Z2, p2), Z2)


def test_real_sh_conventions_match_pyscf():
    basis = {"O": gto.basis.parse("O S\n 1.0 1.0\nO P\n 1.0 1.0\nO D\n 1.0 1.0")}
    m = gto.M(atom="O 0 0 0", basis=basis, verbose=0)
    pts = np.random.default_rng(1).normal(size=(40, 3)); pts /= np.linalg.norm(pts, axis=1, keepdims=True)
    ao = m.eval_gto("GTOval_sph", pts * 0.7)
    for l, sl in [(1, slice(1, 4)), (2, slice(4, 9))]:
        ref = ao_real_sh(l, pts)
        scale = (ao[:, sl] * ref).sum(0) / (ref * ref).sum(0)
        assert np.allclose(scale, scale[0]) and scale[0] > 0
        assert np.abs(ao[:, sl] - ref * scale).max() < 1e-10


def test_dft_hamiltonian_solves_roothaan():
    from scipy.linalg import eigh
    Z, pos = WATER
    r = run_dft(Z, pos)
    S = overlap(build_mol(Z, pos))
    e, C = eigh(r["H"], S)
    assert np.allclose(C.T @ S @ C, np.eye(len(S)), atol=1e-8)
    assert r["converged"]
