import numpy as np
from qh9.qm9 import parse_xyz


def test_parse_qm9_xyz(tmp_path):
    txt = ("3\ngdb 1 1.0 2.0\nO 0.0 0.0 0.1173*^-1 -0.5\nH 0.0 0.757 -0.469 0.2\nH 0.0 -0.757 -0.469 0.2\n"
           "1.0 2.0 3.0\nO\nO\nInChI=1S/H2O\nInChI=1S/H2O\n")
    f = tmp_path / "dsgdb9nsd_000042.xyz"; f.write_text(txt)
    r = parse_xyz(str(f))
    assert r.qm9_id == 42 and list(r.numbers) == [8, 1, 1] and abs(r.positions[0, 2] - 0.01173) < 1e-12


def test_nve_short_run():
    from qh9.md import run_nve
    Z = [8, 1, 1]; pos = np.array([[0, 0, .117], [0, .757, -.469], [0, -.757, -.469]])
    fr = run_nve(Z, pos, calculator="pyscf", n_steps=20, sample_every=10)
    assert fr.shape == (2, 3, 3) and np.allclose(fr[0], pos)
    assert not np.allclose(fr[1], pos)
