import numpy as np
from qh9 import splits


def test_stable_id_counts():
    s = splits.stable_id(np.arange(130831))
    assert [len(s[k]) for k in ("train", "valid", "test")] == [104664, 13083, 13084]
    assert len(set(s["train"]) & set(s["test"])) == 0


def test_dynamic_counts():
    mol = np.repeat(np.arange(999), 100); ids = np.arange(99900)
    g = splits.dynamic_geo(ids, mol)
    assert [len(g[k]) for k in ("train", "valid", "test")] == [79920, 9990, 9990]
    m = splits.dynamic_mol(ids, mol)
    assert [len(m[k]) for k in ("train", "valid", "test")] == [79900, 9900, 10100]
    # molecule-wise: no molecule shared across subsets
    mt, ms = set(mol[m["train"]]), set(mol[m["test"]])
    assert not (mt & ms)


def test_ood_ranges():
    n = np.random.default_rng(0).integers(3, 30, size=5000); ids = np.arange(5000)
    s = splits.stable_ood(ids, n)
    assert n[s["train"]].max() <= 20 and 21 <= n[s["valid"]].min() and n[s["valid"]].max() <= 22 and n[s["test"]].min() >= 23
