import numpy as np, torch
from e3nn import o3
from qh9.model import QHNet, QHNetConfig
from qh9.dataset import collate
from qh9.orbitals import basis_change, SHELLS, n_orbitals, shell_offsets

torch.manual_seed(0)
CFG = QHNetConfig(hidden_mul=8, pair_mul=4, num_layers=2, num_rbf=8, radial_hidden=16)


def make_sample(Z, pos):
    nao = sum(n_orbitals(z) for z in Z)
    return dict(Z=np.array(Z), pos=np.array(pos, dtype=np.float64), H=np.zeros((nao, nao)))


def ao_wigner(Z, R):
    """Block-diagonal Wigner-D in the PySCF AO basis for rotation R."""
    blocks = []
    for z in Z:
        for l, _ in shell_offsets(z):
            D = o3.Irrep(l, 1).D_from_matrix(torch.tensor(R, dtype=torch.float64)).numpy()
            M = basis_change(l)
            blocks.append(M @ D @ M.T)
    n = sum(b.shape[0] for b in blocks)
    out, i = np.zeros((n, n)), 0
    for b in blocks:
        k = b.shape[0]; out[i:i + k, i:i + k] = b; i += k
    return out


def predict(model, Z, pos):
    b = collate([make_sample(Z, pos)])
    with torch.no_grad():
        return model(b).numpy().reshape(b.mol_nao[0], -1).astype(np.float64)


def test_shapes_symmetry():
    model = QHNet(CFG).eval()
    Z = [6, 8, 1, 1, 7]; pos = np.random.default_rng(0).normal(size=(5, 3)) * 1.3
    H = predict(model, Z, pos)
    assert H.shape == (14 + 14 + 5 + 5 + 14,) * 2
    assert np.allclose(H, H.T, atol=1e-6)


def test_rotation_equivariance():
    model = QHNet(CFG).eval().double()
    Z = [6, 8, 1, 1, 7]; pos = np.random.default_rng(1).normal(size=(5, 3)) * 1.3
    R = o3.rand_matrix().double().numpy()
    def run(p):
        b = collate([make_sample(Z, p)]); b.pos = b.pos.double()
        with torch.no_grad():
            return model(b).numpy().reshape(b.mol_nao[0], -1)
    H0, H1 = run(pos), run(pos @ R.T)
    D = ao_wigner(Z, R)
    scale = np.abs(H0).max()
    assert np.abs(H1 - D @ H0 @ D.T).max() < 1e-4 * max(scale, 1e-3), np.abs(H1 - D @ H0 @ D.T).max()


def test_permutation_equivariance():
    model = QHNet(CFG).eval()
    Z = np.array([6, 8, 1, 1, 7]); pos = np.random.default_rng(2).normal(size=(5, 3)) * 1.3
    perm = np.array([3, 0, 4, 1, 2])
    H0 = predict(model, Z, pos); H1 = predict(model, Z[perm], pos[perm])
    ao = [np.arange(n_orbitals(z)) + o for z, o in zip(Z, np.cumsum([0] + [n_orbitals(z) for z in Z])[:-1])]
    idx = np.concatenate([ao[i] for i in perm])
    assert np.abs(H1 - H0[np.ix_(idx, idx)]).max() < 1e-5
