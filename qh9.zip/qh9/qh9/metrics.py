"""Evaluation metrics (paper Sec. 3.4): Hamiltonian MAE (diag / off-diag / all),
occupied orbital-energy MAE, cosine similarity of occupied orbital coefficients."""
from __future__ import annotations

from typing import Dict

import numpy as np
import scipy.linalg


def flat_mae_per_molecule(pred, target, diag_mask, elem_mol, n_mol):
    """Torch: per-molecule MAE on diagonal blocks, off-diagonal blocks and all elements."""
    import torch
    err = (pred - target).abs()
    out = {}
    for name, m in (("diag", diag_mask), ("offdiag", ~diag_mask), ("all", torch.ones_like(diag_mask))):
        s = torch.zeros(n_mol, dtype=err.dtype, device=err.device).index_add_(0, elem_mol[m], err[m])
        c = torch.zeros(n_mol, dtype=err.dtype, device=err.device).index_add_(0, elem_mol[m], torch.ones_like(err[m]))
        out[name] = s / c.clamp(min=1)
    return out


def diag_block_mask(ao_atom: np.ndarray) -> np.ndarray:
    return ao_atom[:, None] == ao_atom[None, :]


def hamiltonian_mae(H_pred: np.ndarray, H_true: np.ndarray, ao_atom: np.ndarray) -> Dict[str, float]:
    err = np.abs(H_pred - H_true)
    m = diag_block_mask(ao_atom)
    return dict(diag=float(err[m].mean()), offdiag=float(err[~m].mean()), all=float(err.mean()))


def solve_orbitals(H: np.ndarray, S: np.ndarray):
    """Generalised eigenproblem  H C = eps S C  (paper Eq. 2). Returns (eps, C)."""
    return scipy.linalg.eigh(H, S)


def orbital_metrics(H_pred, H_true, S, n_electrons: int) -> Dict[str, float]:
    n_occ = n_electrons // 2
    e_p, C_p = solve_orbitals(H_pred, S)
    e_t, C_t = solve_orbitals(H_true, S)
    eps_mae = float(np.abs(e_p[:n_occ] - e_t[:n_occ]).mean())
    a, b = C_p[:, :n_occ], C_t[:, :n_occ]
    cos = np.abs((a * b).sum(0)) / (np.linalg.norm(a, axis=0) * np.linalg.norm(b, axis=0))  # |.|: sign ambiguity
    return dict(eps_mae=eps_mae, psi_cos=float(cos.mean()))


def density_from_hamiltonian(H, S, n_electrons: int) -> np.ndarray:
    """Closed-shell density matrix  P = 2 C_occ C_occ^T  from a (predicted) Hamiltonian."""
    _, C = solve_orbitals(H, S)
    c = C[:, : n_electrons // 2]
    return 2.0 * c @ c.T
