"""QHNet-style SE(3)-equivariant Hamiltonian predictor (e3nn).

Structure (following the description of QHNet used as the paper's baseline):
  1. node embedding of atomic numbers into irreps features
  2. 5 node-wise interaction layers (tensor-product messages with radial-basis weights + gate)
  3. expansion module: atom-pair irreps (diagonal: from node features; off-diagonal: node i,
     node j and edge spherical harmonics) are expanded into full orbital-pair blocks using
     Clebsch-Gordan coefficients, mapped to the PySCF AO basis, assembled into H and symmetrised.

This is a faithful-in-spirit re-implementation from the paper's description plus general
knowledge of QHNet, NOT the official code; hidden sizes etc. are configurable.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict

import torch
import torch.nn as nn
import torch.nn.functional as F
from e3nn import o3
from e3nn.nn import Gate

from .orbitals import ELEMENTS, block_irreps, block_spec, expansion_matrix, n_orbitals


@dataclass
class QHNetConfig:
    hidden_mul: int = 64
    lmax: int = 4            # max l of hidden features
    sh_lmax: int = 4         # max l of edge spherical harmonics
    num_layers: int = 5
    num_rbf: int = 32
    cutoff: float = 12.0
    radial_hidden: int = 64
    pair_mul: int = 24
    avg_neighbors: float = 15.0

    def to_dict(self):
        return asdict(self)


def tp_uvu(irreps_in1, irreps_in2, irreps_allowed):
    out, instr = [], []
    for i, (mul, ir1) in enumerate(irreps_in1):
        for j, (_, ir2) in enumerate(irreps_in2):
            for ir_out in ir1 * ir2:
                if ir_out in irreps_allowed:
                    instr.append((i, j, len(out), "uvu", True))
                    out.append((mul, ir_out))
    return o3.Irreps(out), instr


def make_hidden_irreps(mul: int, lmax: int):
    scalars = o3.Irreps(f"{mul}x0e")
    gated = o3.Irreps([(mul, (l, p)) for l in range(1, lmax + 1) for p in (1, -1)])
    return scalars, gated


class GaussianRBF(nn.Module):
    def __init__(self, n: int, cutoff: float):
        super().__init__()
        self.cutoff = cutoff
        self.register_buffer("mu", torch.linspace(0, cutoff, n))
        self.coeff = -0.5 / (cutoff / (n - 1)) ** 2

    def forward(self, d):
        env = 0.5 * (torch.cos(math.pi * d / self.cutoff) + 1.0) * (d < self.cutoff)
        return torch.exp(self.coeff * (d[:, None] - self.mu[None]) ** 2) * env[:, None]


def mlp(n_in, n_hidden, n_out):
    return nn.Sequential(nn.Linear(n_in, n_hidden), nn.SiLU(), nn.Linear(n_hidden, n_hidden), nn.SiLU(),
                         nn.Linear(n_hidden, n_out))


class InteractionLayer(nn.Module):
    def __init__(self, irreps_hidden, irreps_sh, scalars, gated, num_rbf, radial_hidden, avg_neighbors):
        super().__init__()
        self.norm = 1.0 / math.sqrt(avg_neighbors)
        self.lin_in = o3.Linear(irreps_hidden, irreps_hidden)
        tp_out, instr = tp_uvu(irreps_hidden, irreps_sh, irreps_hidden)
        self.tp = o3.TensorProduct(irreps_hidden, irreps_sh, tp_out, instr, shared_weights=False,
                                   internal_weights=False)
        self.radial = mlp(num_rbf, radial_hidden, self.tp.weight_numel)
        gates = o3.Irreps(f"{gated.num_irreps}x0e")
        preact = scalars + gates + gated
        self.lin_out = o3.Linear(tp_out, preact)
        self.skip = o3.Linear(irreps_hidden, preact)
        self.gate = Gate(scalars, [F.silu], gates, [torch.sigmoid], gated)

    def forward(self, h, src, dst, sh, rbf):
        x = self.lin_in(h)
        msg = self.tp(x[src], sh, self.radial(rbf))
        agg = torch.zeros(h.shape[0], msg.shape[1], dtype=msg.dtype, device=msg.device).index_add_(0, dst, msg)
        return self.gate(self.lin_out(agg * self.norm) + self.skip(h))


class QHNet(nn.Module):
    def __init__(self, cfg: QHNetConfig = QHNetConfig()):
        super().__init__()
        self.cfg = cfg
        scalars, gated = make_hidden_irreps(cfg.hidden_mul, cfg.lmax)
        self.irreps_hidden = scalars + gated
        self.irreps_sh = o3.Irreps.spherical_harmonics(cfg.sh_lmax)
        self.register_buffer("z2i", torch.full((10,), -1, dtype=torch.long))
        for i, z in enumerate(ELEMENTS):
            self.z2i[z] = i
        self.embed = nn.Embedding(len(ELEMENTS), cfg.hidden_mul)
        self.embed_lin = o3.Linear(f"{cfg.hidden_mul}x0e", self.irreps_hidden)
        self.rbf = GaussianRBF(cfg.num_rbf, cfg.cutoff)
        self.layers = nn.ModuleList([
            InteractionLayer(self.irreps_hidden, self.irreps_sh, scalars, gated, cfg.num_rbf,
                             cfg.radial_hidden, cfg.avg_neighbors) for _ in range(cfg.num_layers)])

        # ---- expansion module ------------------------------------------------
        self.irreps_out = block_irreps()
        pair_s, pair_g = make_hidden_irreps(cfg.pair_mul, cfg.lmax)
        self.irreps_pair = pair_s + pair_g
        self.lin_diag = o3.Linear(self.irreps_hidden, self.irreps_pair)
        self.tp_diag = o3.FullyConnectedTensorProduct(self.irreps_pair, self.irreps_pair, self.irreps_out)
        self.lin_a = o3.Linear(self.irreps_hidden, self.irreps_pair)
        self.lin_b = o3.Linear(self.irreps_hidden, self.irreps_pair)
        geo_out, geo_instr = tp_uvu(self.irreps_pair, self.irreps_sh, self.irreps_pair)
        self.tp_geo = o3.TensorProduct(self.irreps_pair, self.irreps_sh, geo_out, geo_instr,
                                       shared_weights=False, internal_weights=False)
        self.radial_geo = mlp(cfg.num_rbf, cfg.radial_hidden, self.tp_geo.weight_numel)
        self.lin_g = o3.Linear(geo_out, self.irreps_pair)
        self.tp_off = o3.FullyConnectedTensorProduct(self.irreps_pair, self.irreps_pair, self.irreps_out)
        # per-element bias on the scalar (0e) output channels of diagonal blocks (keeps equivariance)
        n0 = block_spec()[1][(0, 1)]
        self.diag_bias = nn.Embedding(len(ELEMENTS), n0)
        nn.init.zeros_(self.diag_bias.weight)
        # CG expansion matrices -> AO blocks
        for zi in ELEMENTS:
            for zj in ELEMENTS:
                self.register_buffer(f"A_{zi}_{zj}", torch.tensor(expansion_matrix(zi, zj), dtype=torch.float32),
                                     persistent=False)

    # ------------------------------------------------------------------
    def _graph(self, pos, batch):
        d = torch.cdist(pos, pos)
        mask = (batch[:, None] == batch[None, :]) & (d < self.cfg.cutoff)
        mask &= ~torch.eye(len(pos), dtype=torch.bool, device=pos.device)
        dst, src = mask.nonzero(as_tuple=True)
        vec = pos[src] - pos[dst]
        return src, dst, vec, vec.norm(dim=1)

    @staticmethod
    def _place(flat, blocks, ni, nj, rows_atom, cols_atom, b):
        m = b.batch[rows_atom]
        ar_i = torch.arange(ni, device=flat.device)[None, :, None]
        ar_j = torch.arange(nj, device=flat.device)[None, None, :]
        r = b.ao_off[rows_atom][:, None, None] + ar_i
        c = b.ao_off[cols_atom][:, None, None] + ar_j
        idx = b.mol_base[m][:, None, None] + r * b.mol_nao[m][:, None, None] + c
        return flat.index_put((idx.reshape(-1),), blocks.reshape(-1))

    def forward(self, b):
        """Returns flat predicted Hamiltonians (all molecules concatenated, row-major)."""
        zi = self.z2i[b.z]
        h = self.embed_lin(self.embed(zi))
        src, dst, vec, dist = self._graph(b.pos, b.batch)
        sh = o3.spherical_harmonics(self.irreps_sh, vec, normalize=True, normalization="component")
        rbf = self.rbf(dist)
        for layer in self.layers:
            h = layer(h, src, dst, sh, rbf)

        # diagonal blocks
        p = self.lin_diag(h)
        diag = self.tp_diag(p, p)
        n0 = self.diag_bias.num_embeddings and self.diag_bias.weight.shape[1]
        diag = torch.cat([diag[:, :n0] + self.diag_bias(zi), diag[:, n0:]], dim=1)
        # off-diagonal blocks (ordered pairs; block (dst, src))
        a = self.lin_a(h)[dst]
        g = self.lin_g(self.tp_geo(self.lin_b(h)[src], sh, self.radial_geo(rbf)))
        off = self.tp_off(a, g)

        total = int((b.mol_nao ** 2).sum())
        flat = torch.zeros(total, dtype=h.dtype, device=h.device)
        zs = b.z
        for z in ELEMENTS:
            sel = (zs == z).nonzero(as_tuple=True)[0]
            if len(sel):
                A = getattr(self, f"A_{z}_{z}")
                n = n_orbitals(z)
                flat = self._place(flat, diag[sel] @ A.T, n, n, sel, sel, b)
        for zi_ in ELEMENTS:
            for zj_ in ELEMENTS:
                e = ((zs[dst] == zi_) & (zs[src] == zj_)).nonzero(as_tuple=True)[0]
                if len(e):
                    A = getattr(self, f"A_{zi_}_{zj_}")
                    flat = self._place(flat, off[e] @ A.T, n_orbitals(zi_), n_orbitals(zj_), dst[e], src[e], b)
        return 0.5 * (flat + flat[b.transpose_idx])
