"""Command-line interface:  qh9 <command> ..."""
from __future__ import annotations

import argparse
import json

import numpy as np

TASKS = ["stable-id", "stable-ood", "dynamic-geo", "dynamic-mol"]


def main(argv=None):
    p = argparse.ArgumentParser(prog="qh9")
    sp = p.add_subparsers(dest="cmd", required=True)

    a = sp.add_parser("gen-stable", help="DFT Hamiltonians for all QM9 geometries")
    a.add_argument("--qm9-dir", required=True); a.add_argument("--uncharacterized")
    a.add_argument("--out", required=True); a.add_argument("--workers", type=int, default=1)

    a = sp.add_parser("gen-dynamic", help="NVE MD + DFT for 999 molecules x 100 geometries")
    a.add_argument("--qm9-dir", required=True); a.add_argument("--uncharacterized")
    a.add_argument("--out", required=True); a.add_argument("--workers", type=int, default=1)
    a.add_argument("--calculator", default="pyscf", choices=["pyscf", "xtb"])
    a.add_argument("--n-mol", type=int, default=999)

    a = sp.add_parser("split", help="write a benchmark split json")
    a.add_argument("--root", required=True); a.add_argument("--task", required=True, choices=TASKS)
    a.add_argument("--seed", type=int, default=0)

    a = sp.add_parser("train")
    a.add_argument("--root", required=True); a.add_argument("--split", required=True)
    a.add_argument("--out", required=True); a.add_argument("--steps", type=int, default=260_000)
    a.add_argument("--batch-size", type=int, default=32); a.add_argument("--eval-every", type=int, default=5000)
    a.add_argument("--workers", type=int, default=4)
    a.add_argument("--hidden-mul", type=int, default=64); a.add_argument("--pair-mul", type=int, default=24)

    a = sp.add_parser("eval")
    a.add_argument("--root", required=True); a.add_argument("--split", required=True)
    a.add_argument("--ckpt", required=True); a.add_argument("--which", default="test")
    a.add_argument("--max-orbital-samples", type=int, default=500)
    a.add_argument("--accel", action="store_true", help="also run DFT acceleration ratios (50 molecules)")
    a.add_argument("--device", default="cuda")

    a = sp.add_parser("stats", help="Table-5 style dataset statistics")
    a.add_argument("--root", required=True); a.add_argument("--split", required=True)

    args = p.parse_args(argv)

    if args.cmd in ("gen-stable", "gen-dynamic"):
        from .qm9 import load_qm9
        from . import generate
        recs = load_qm9(args.qm9_dir, args.uncharacterized)
        print(f"{len(recs)} QM9 molecules loaded")
        if args.cmd == "gen-stable":
            generate.generate_stable(recs, args.out, args.workers)
        else:
            generate.generate_dynamic(recs, args.out, args.workers, args.calculator, args.n_mol)
    elif args.cmd == "split":
        import os
        from .dataset import SampleStore
        from .splits import make_split, save_split
        idx = SampleStore(args.root).load_index()
        sp_ = make_split(args.task, idx, args.seed)
        path = os.path.join(args.root, f"split_{args.task}.json")
        save_split(sp_, path)
        print(path, {k: len(v) for k, v in sp_.items()})
    elif args.cmd == "train":
        from .model import QHNetConfig
        from .train import TrainConfig, train
        train(TrainConfig(root=args.root, split=args.split, out_dir=args.out, total_steps=args.steps,
                          batch_size=args.batch_size, eval_every=args.eval_every, num_workers=args.workers),
              QHNetConfig(hidden_mul=args.hidden_mul, pair_mul=args.pair_mul))
    elif args.cmd == "eval":
        from .dataset import QH9Dataset
        from .evaluate import evaluate_acceleration, evaluate_split
        from .splits import load_split
        from .train import load_model
        model = load_model(args.ckpt, args.device)
        ds = QH9Dataset(args.root, load_split(args.split)[args.which])
        print(json.dumps(evaluate_split(model, ds, args.device, args.max_orbital_samples), indent=1))
        if args.accel:
            print(json.dumps(evaluate_acceleration(model, ds, 50, device=args.device), indent=1))
    elif args.cmd == "stats":
        from .analysis import dataset_statistics
        from .dataset import SampleStore
        from .splits import load_split
        print(json.dumps(dataset_statistics(SampleStore(args.root).load_index(), load_split(args.split)), indent=1))


if __name__ == "__main__":
    main()
