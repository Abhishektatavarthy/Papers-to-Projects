"""QH9-style quantum Hamiltonian benchmark package."""
__version__ = "0.1.0"
