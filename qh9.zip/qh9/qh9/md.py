"""NVE molecular dynamics used for QH9-dynamic (paper Sec. 3.1).

Paper settings: microcanonical ensemble, 300 K, 0.12 fs integration step, 1,000 steps,
100 geometries sampled every 10 steps (1.2 fs).  The paper does not name the MD engine or
force model; here ASE's velocity-Verlet is used with a pluggable force calculator
('pyscf' = same B3LYP/Def2-SVP level with looser SCF, or 'xtb' via tblite as a cheap option).
"""
from __future__ import annotations

import numpy as np

from .dft import build_mol, make_mf


def make_calculator(kind: str = "pyscf"):
    if kind == "xtb":
        from tblite.ase import TBLite
        return TBLite(method="GFN2-xTB", verbosity=0)
    if kind != "pyscf":
        raise ValueError(kind)
    from ase import units
    from ase.calculators.calculator import Calculator, all_changes

    class PySCFCalc(Calculator):
        implemented_properties = ["energy", "forces"]

        def calculate(self, atoms=None, properties=("energy",), system_changes=all_changes):
            super().calculate(atoms, properties, system_changes)
            mol = build_mol(atoms.numbers, atoms.positions)
            mf = make_mf(mol, grid_level=2, conv_tol=1e-9, conv_tol_grad=1e-5)
            mf.kernel()
            g = mf.nuc_grad_method().kernel()  # Hartree/Bohr
            self.results["energy"] = float(mf.e_tot) * units.Hartree
            self.results["forces"] = -np.asarray(g) * units.Hartree / units.Bohr

    return PySCFCalc()


def run_nve(numbers, positions, calculator: str = "pyscf", temperature: float = 300.0,
            dt_fs: float = 0.12, n_steps: int = 1000, sample_every: int = 10, seed: int = 0):
    """Return array (n_steps // sample_every, n_atoms, 3) of sampled geometries in Angstrom."""
    from ase import Atoms, units
    from ase.md.velocitydistribution import MaxwellBoltzmannDistribution, Stationary, ZeroRotation
    from ase.md.verlet import VelocityVerlet

    atoms = Atoms(numbers=list(map(int, numbers)), positions=positions)
    atoms.calc = make_calculator(calculator)
    MaxwellBoltzmannDistribution(atoms, temperature_K=temperature, rng=np.random.default_rng(seed))
    Stationary(atoms)
    ZeroRotation(atoms)
    dyn = VelocityVerlet(atoms, timestep=dt_fs * units.fs)
    frames = []
    for _ in range(n_steps // sample_every):
        frames.append(atoms.get_positions().copy())  # steps 0, 10, ..., 990
        dyn.run(sample_every)
    return np.stack(frames)
