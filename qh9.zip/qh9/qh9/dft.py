"""PySCF DFT utilities: molecule construction and converged-Hamiltonian generation.

Settings follow the paper (Sec. 3.1): B3LYP / Def2-SVP, grid level 3, SCF tol 1e-13,
gradient threshold 3.16e-5, DIIS with 8 previous steps.
"""
from __future__ import annotations

import numpy as np

from .orbitals import SYMBOL, n_electrons, shell_offsets, SHELLS

DFT_SETTINGS = dict(xc="b3lyp", basis="def2svp", grid_level=3, conv_tol=1e-13,
                    conv_tol_grad=3.16e-5, diis_space=8, max_cycle=200)


def build_mol(numbers, positions, basis: str = "def2svp"):
    from pyscf import gto
    atoms = [(SYMBOL[int(z)], tuple(float(c) for c in p)) for z, p in zip(numbers, positions)]
    return gto.M(atom=atoms, basis=basis, unit="Angstrom", charge=0, spin=0, verbose=0)


def make_mf(mol, **overrides):
    from pyscf import dft
    s = {**DFT_SETTINGS, **overrides}
    mf = dft.RKS(mol)
    mf.xc = s["xc"]
    mf.grids.level = s["grid_level"]
    mf.conv_tol = s["conv_tol"]
    mf.conv_tol_grad = s["conv_tol_grad"]
    mf.diis_space = s["diis_space"]
    mf.max_cycle = s["max_cycle"]
    return mf


def overlap(mol) -> np.ndarray:
    return mol.intor_symmetric("int1e_ovlp")


def run_dft(numbers, positions, **overrides) -> dict:
    """Run converged DFT and return the Fock/Hamiltonian matrix (AO basis, Hartree)."""
    mol = build_mol(numbers, positions)
    attempts = [dict(), dict(init_guess="atom", level_shift=0.2)]
    last = None
    for extra in attempts:
        mf = make_mf(mol, **overrides)
        for k, v in extra.items():
            setattr(mf, k, v)
        cycles = []
        mf.callback = lambda envs: cycles.append(1)
        mf.kernel()
        last = mf
        if mf.converged:
            break
    if not last.converged:
        raise RuntimeError("SCF did not converge")
    dm = last.make_rdm1()
    H = np.asarray(last.get_fock(dm=dm))
    return dict(H=H, e_tot=float(last.e_tot), scf_cycles=len(cycles), converged=True)


def verify_ao_layout(mol, numbers) -> None:
    """Assert PySCF's AO ordering matches the static Def2-SVP layout used by the model."""
    found = {}
    for b in range(mol.nbas):
        found.setdefault(mol.bas_atom(b), []).append(mol.bas_angular(b))
        assert mol.bas_nctr(b) == 1, "general contraction not supported"
    for a, z in enumerate(numbers):
        assert tuple(found[a]) == SHELLS[int(z)], f"atom {a} (Z={z}): shells {found[a]} != {SHELLS[int(z)]}"
    assert mol.nao == sum(sum(2 * l + 1 for l in SHELLS[int(z)]) for z in numbers)
    assert mol.nelectron == n_electrons(numbers)


def ao_atom_index(numbers) -> np.ndarray:
    """For each AO, the index of the atom it sits on."""
    from .orbitals import n_orbitals
    return np.concatenate([np.full(n_orbitals(z), i) for i, z in enumerate(numbers)])
