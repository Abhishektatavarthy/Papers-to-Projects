"""Full evaluation of a trained model on a split: H MAE (diag/off-diag/all), orbital-energy MAE,
orbital-coefficient cosine similarity, and (optionally) DFT acceleration ratios."""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
import torch

from .accel import acceleration_ratios, summarize
from .dataset import QH9Dataset, make_loader, split_flat_to_matrices
from .dft import ao_atom_index, build_mol, overlap
from .metrics import hamiltonian_mae, orbital_metrics
from .orbitals import n_electrons


@torch.no_grad()
def predict_matrices(model, ds: QH9Dataset, device="cpu", batch_size=16, num_workers=0):
    """Yield (sample_dict, H_pred[np.float64]) for every sample in ds (order preserved)."""
    model.eval()
    k = 0
    for b in make_loader(ds, batch_size, False, num_workers):
        flat = model(b.to(device)).double().cpu().numpy()
        mats = split_flat_to_matrices(flat, b.mol_nao.cpu().numpy(), b.mol_base.cpu().numpy())
        for H in mats:
            yield ds[k], H
            k += 1


def evaluate_split(model, ds: QH9Dataset, device="cpu", max_orbital_samples: Optional[int] = 500,
                   batch_size=16, num_workers=0) -> Dict[str, float]:
    rows = {"h_diag": [], "h_offdiag": [], "h_all": [], "eps_mae": [], "psi_cos": []}
    for i, (s, Hp) in enumerate(predict_matrices(model, ds, device, batch_size, num_workers)):
        m = hamiltonian_mae(Hp, s["H"], ao_atom_index(s["Z"]))
        rows["h_diag"].append(m["diag"]); rows["h_offdiag"].append(m["offdiag"]); rows["h_all"].append(m["all"])
        if max_orbital_samples is None or i < max_orbital_samples:
            S = overlap(build_mol(s["Z"], s["pos"]))
            o = orbital_metrics(Hp, s["H"], S, n_electrons(s["Z"]))
            rows["eps_mae"].append(o["eps_mae"]); rows["psi_cos"].append(o["psi_cos"])
    out = {k: float(np.mean(v)) for k, v in rows.items() if v}
    out.update({k + "_1e-6Eh": v * 1e6 for k, v in out.items() if k.startswith(("h_", "eps"))})
    return out


def evaluate_acceleration(model, ds: QH9Dataset, n_samples: int = 50, seed: int = 0, device="cpu"):
    """Acceleration ratios on n random samples (paper: 50 molecules), for 'minao' and '1e' guesses."""
    rng = np.random.default_rng(seed)
    pick = rng.choice(len(ds), size=min(n_samples, len(ds)), replace=False)
    sub = QH9Dataset(ds.store.root, ds.ids[pick])
    res = {"minao": [], "1e": []}
    for s, Hp in predict_matrices(model, sub, device, batch_size=8):
        for g in res:
            res[g].append(acceleration_ratios(s["Z"], s["pos"], Hp, s["H"], init_guess=g))
    return {g: summarize(r) for g, r in res.items()}
