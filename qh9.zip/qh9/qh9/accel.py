"""DFT acceleration metrics (paper Sec. 3.4 / Table 4).

* optimal ratio   = 1 / T_base                      (one SCF step vs. full baseline run)
* achieved ratio  = T_pred / T_base                 (lower is better)
* error-level ratio = k* / T_base                   (higher is better), where k* is the first baseline SCF
  step whose Fock matrix has MAE-to-converged-H <= MAE of the model prediction.
T_base is measured with a standard initial guess ('minao' or '1e').
Definitions of the last two are interpreted from the paper's prose.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from .dft import build_mol, make_mf, overlap
from .metrics import density_from_hamiltonian
from .orbitals import n_electrons


def _run(mol, init_guess=None, dm0=None, record_fock=False):
    mf = make_mf(mol)
    if init_guess:
        mf.init_guess = init_guess
    focks, count = [], [0]

    def cb(envs):
        count[0] += 1
        if record_fock and "fock" in envs:
            focks.append(np.array(envs["fock"]))

    mf.callback = cb
    mf.kernel(dm0=dm0)
    return mf, count[0], focks


def acceleration_ratios(numbers, positions, H_pred, H_true, init_guess: str = "minao") -> Dict[str, float]:
    mol = build_mol(numbers, positions)
    S = overlap(mol)
    _, T_base, focks = _run(mol, init_guess=init_guess, record_fock=True)
    dm0 = density_from_hamiltonian(H_pred, S, n_electrons(numbers))
    _, T_pred, _ = _run(mol, dm0=dm0)
    model_err = np.abs(H_pred - H_true).mean()
    errs = [np.abs(f - H_true).mean() for f in focks]
    k_star = next((k + 1 for k, e in enumerate(errs) if e <= model_err), T_base)
    return dict(optimal=1.0 / T_base, achieved=T_pred / T_base, error_level=k_star / T_base,
                T_base=T_base, T_pred=T_pred)


def summarize(rows: List[Dict[str, float]]) -> Dict[str, str]:
    out = {}
    for k in ("optimal", "achieved", "error_level"):
        v = np.array([r[k] for r in rows])
        out[k] = f"{v.mean():.3f}±{v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0:.3f}"
    return out
