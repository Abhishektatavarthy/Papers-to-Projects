"""Minimal QM9 (dsgdb9nsd_*.xyz) reader.

The 130,831-molecule QM9 version used by the paper = the 133,885 molecules minus the
3,054 'uncharacterized' ones (file uncharacterized.txt shipped with QM9, figshare 978904).
"""
from __future__ import annotations

import glob
import os
import re
from dataclasses import dataclass
from typing import List, Optional, Set

import numpy as np

Z_OF = {"H": 1, "C": 6, "N": 7, "O": 8, "F": 9}


@dataclass
class QM9Record:
    qm9_id: int
    numbers: np.ndarray
    positions: np.ndarray  # Angstrom
    smiles: str = ""


def _f(tok: str) -> float:
    return float(tok.replace("*^", "e"))


def parse_xyz(path: str) -> QM9Record:
    with open(path) as fh:
        lines = fh.read().splitlines()
    n = int(lines[0])
    nums, pos = [], []
    for ln in lines[2:2 + n]:
        t = ln.split()
        nums.append(Z_OF[t[0]])
        pos.append([_f(t[1]), _f(t[2]), _f(t[3])])
    smiles = lines[3 + n].split()[0] if len(lines) > 3 + n else ""
    qid = int(re.findall(r"(\d+)\.xyz$", os.path.basename(path))[0])
    return QM9Record(qid, np.array(nums, dtype=np.int64), np.array(pos, dtype=np.float64), smiles)


def read_uncharacterized(path: str) -> Set[int]:
    ids = set()
    with open(path) as fh:
        for ln in fh:
            t = ln.split()
            if t and t[0].isdigit():
                ids.add(int(t[0]))
    return ids


def load_qm9(xyz_dir: str, uncharacterized: Optional[str] = None) -> List[QM9Record]:
    files = sorted(glob.glob(os.path.join(xyz_dir, "dsgdb9nsd_*.xyz")))
    if not files:
        raise FileNotFoundError(f"no dsgdb9nsd_*.xyz in {xyz_dir}")
    bad = read_uncharacterized(uncharacterized) if uncharacterized else set()
    recs = [parse_xyz(f) for f in files]
    recs = [r for r in recs if r.qm9_id not in bad]
    return recs
