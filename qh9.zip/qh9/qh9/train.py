"""Training loop: batch 32, linear warm-up 0 -> 5e-4 over 1,000 steps, linear decay to 1e-7 (paper Sec. 4)."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict

import numpy as np
import torch

from .dataset import QH9Dataset, make_loader
from .metrics import flat_mae_per_molecule
from .model import QHNet, QHNetConfig
from .splits import load_split


@dataclass
class TrainConfig:
    root: str = "data/qh9_stable"
    split: str = "data/qh9_stable/split_stable-id.json"
    out_dir: str = "runs/stable-id"
    batch_size: int = 32
    total_steps: int = 260_000      # paper: 210k or 260k depending on the task
    warmup_steps: int = 1_000
    lr_max: float = 5e-4
    lr_final: float = 1e-7
    eval_every: int = 5_000
    log_every: int = 100
    num_workers: int = 4
    grad_clip: float = 10.0
    seed: int = 0
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


def lr_factor(step: int, c: TrainConfig) -> float:
    if step < c.warmup_steps:
        return step / c.warmup_steps
    frac = (step - c.warmup_steps) / max(1, c.total_steps - c.warmup_steps)
    return (c.lr_max + (c.lr_final - c.lr_max) * min(frac, 1.0)) / c.lr_max


def loss_fn(pred, target):
    """MAE + MSE on all Hamiltonian entries (loss form not given in the paper; taken from QHNet's convention)."""
    d = pred - target
    return d.abs().mean() + (d ** 2).mean()


@torch.no_grad()
def evaluate_flat(model, ds, device, batch_size=32, num_workers=0):
    model.eval()
    acc = {"diag": [], "offdiag": [], "all": []}
    for b in make_loader(ds, batch_size, False, num_workers):
        b = b.to(device)
        m = flat_mae_per_molecule(model(b), b.H, b.diag_mask, b.elem_mol, len(b.mol_nao))
        for k in acc:
            acc[k].append(m[k].cpu().numpy())
    model.train()
    return {k: float(np.concatenate(v).mean()) for k, v in acc.items()}


def train(cfg: TrainConfig, model_cfg: QHNetConfig = QHNetConfig()):
    torch.manual_seed(cfg.seed); np.random.seed(cfg.seed)
    os.makedirs(cfg.out_dir, exist_ok=True)
    split = load_split(cfg.split)
    tr, va = QH9Dataset(cfg.root, split["train"]), QH9Dataset(cfg.root, split["valid"])
    model = QHNet(model_cfg).to(cfg.device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr_max)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: lr_factor(s, cfg))
    best, step, t0 = float("inf"), 0, time.time()
    while step < cfg.total_steps:
        for b in make_loader(tr, cfg.batch_size, True, cfg.num_workers, drop_last=True):
            b = b.to(cfg.device)
            loss = loss_fn(model(b), b.H)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt.step(); sched.step(); step += 1
            if step % cfg.log_every == 0:
                print(f"step {step} loss {loss.item():.3e} lr {sched.get_last_lr()[0]:.2e} {time.time() - t0:.0f}s", flush=True)
            if step % cfg.eval_every == 0 or step == cfg.total_steps:
                m = evaluate_flat(model, va, cfg.device, cfg.batch_size)
                print(f"[valid] step {step} MAE(all) {m['all'] * 1e6:.2f} diag {m['diag'] * 1e6:.2f} "
                      f"offdiag {m['offdiag'] * 1e6:.2f} (1e-6 Eh)", flush=True)
                ck = dict(model=model.state_dict(), model_cfg=model_cfg.to_dict(), train_cfg=asdict(cfg), step=step)
                torch.save(ck, os.path.join(cfg.out_dir, "last.pt"))
                if m["all"] < best:
                    best = m["all"]; torch.save(ck, os.path.join(cfg.out_dir, "best.pt"))
            if step >= cfg.total_steps:
                break
    return model


def load_model(path: str, device: str = "cpu") -> QHNet:
    ck = torch.load(path, map_location=device)
    model = QHNet(QHNetConfig(**ck["model_cfg"])).to(device)
    model.load_state_dict(ck["model"])
    return model.eval()
