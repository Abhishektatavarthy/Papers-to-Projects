"""The four QH9 benchmark splits (paper Sec. 3.2, Table 1)."""
from __future__ import annotations

import json
from typing import Dict, List

import numpy as np

Split = Dict[str, np.ndarray]


def stable_id(ids: np.ndarray, seed: int = 0) -> Split:
    """Random 80/10/10 over geometries.  For N=130,831 -> 104,664 / 13,083 / 13,084."""
    ids = np.asarray(ids)
    perm = np.random.default_rng(seed).permutation(len(ids))
    n_tr, n_va = int(0.8 * len(ids)), int(0.1 * len(ids))
    return dict(train=ids[perm[:n_tr]], valid=ids[perm[n_tr:n_tr + n_va]], test=ids[perm[n_tr + n_va:]])


def stable_ood(ids: np.ndarray, n_atoms: np.ndarray) -> Split:
    """Split by size: train 3-20 atoms, valid 21-22, test 23-29."""
    ids, n = np.asarray(ids), np.asarray(n_atoms)
    return dict(train=ids[(n >= 3) & (n <= 20)], valid=ids[(n >= 21) & (n <= 22)], test=ids[(n >= 23) & (n <= 29)])


def dynamic_geo(ids: np.ndarray, mol_ids: np.ndarray, seed: int = 0) -> Split:
    """Per molecule, its 100 geometries -> 80/10/10 (molecules visible at test time)."""
    ids, mol_ids = np.asarray(ids), np.asarray(mol_ids)
    rng = np.random.default_rng(seed)
    parts = {"train": [], "valid": [], "test": []}
    for m in np.unique(mol_ids):
        g = ids[mol_ids == m]
        g = g[rng.permutation(len(g))]
        n_tr, n_va = int(0.8 * len(g)), int(0.1 * len(g))
        parts["train"].append(g[:n_tr]); parts["valid"].append(g[n_tr:n_tr + n_va]); parts["test"].append(g[n_tr + n_va:])
    return {k: np.concatenate(v) for k, v in parts.items()}


def dynamic_mol(ids: np.ndarray, mol_ids: np.ndarray, seed: int = 0) -> Split:
    """80/10/10 over molecules (999 -> 799/99/101); all geometries of a molecule stay together."""
    ids, mol_ids = np.asarray(ids), np.asarray(mol_ids)
    mols = np.unique(mol_ids)
    mols = mols[np.random.default_rng(seed).permutation(len(mols))]
    n_tr, n_va = int(0.8 * len(mols)), int(0.1 * len(mols))
    sel = lambda ms: ids[np.isin(mol_ids, ms)]
    return dict(train=sel(mols[:n_tr]), valid=sel(mols[n_tr:n_tr + n_va]), test=sel(mols[n_tr + n_va:]))


def make_split(task: str, index: List[dict], seed: int = 0) -> Split:
    ids = np.array([e["id"] for e in index])
    if task == "stable-id":
        return stable_id(ids, seed)
    if task == "stable-ood":
        return stable_ood(ids, np.array([e["n_atoms"] for e in index]))
    mol = np.array([e["mol_id"] for e in index])
    if task == "dynamic-geo":
        return dynamic_geo(ids, mol, seed)
    if task == "dynamic-mol":
        return dynamic_mol(ids, mol, seed)
    raise ValueError(task)


def save_split(split: Split, path: str) -> None:
    with open(path, "w") as fh:
        json.dump({k: [int(i) for i in v] for k, v in split.items()}, fh)


def load_split(path: str) -> Split:
    with open(path) as fh:
        return {k: np.array(v, dtype=np.int64) for k, v in json.load(fh).items()}
