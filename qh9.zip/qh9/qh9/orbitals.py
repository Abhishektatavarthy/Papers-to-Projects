"""Def2-SVP orbital layout (H, C, N, O, F) in PySCF AO ordering and the
basis change between PySCF real-spherical AOs and e3nn real irreps.

Layout (PySCF, spherical):  H = s s p (5 AOs);  C/N/O/F = s s s p p d (14 AOs).
PySCF orders p as (x, y, z) and d as (xy, yz, z2, xz, x2-y2); e3nn uses a
different real-harmonic basis, so we compute an orthogonal matrix M_l numerically
such that  Y_e3nn = Y_ao @ M_l  and then  H_ao_block = M_la @ H_e3_block @ M_lb^T.
"""
from __future__ import annotations

import functools
import math

import numpy as np

ELEMENTS = (1, 6, 7, 8, 9)
SYMBOL = {1: "H", 6: "C", 7: "N", 8: "O", 9: "F"}
HEAVY_SHELLS = (0, 0, 0, 1, 1, 2)
SHELLS = {1: (0, 0, 1), 6: HEAVY_SHELLS, 7: HEAVY_SHELLS, 8: HEAVY_SHELLS, 9: HEAVY_SHELLS}
# index of each hydrogen shell inside the heavy-atom shell list (s, s, p)
H_TO_HEAVY = (0, 1, 3)
VALENCE_ELECTRONS_TOTAL = {1: 1, 6: 6, 7: 7, 8: 8, 9: 9}  # all-electron calc


def n_orbitals(z: int) -> int:
    return sum(2 * l + 1 for l in SHELLS[int(z)])


def shell_offsets(z: int):
    """[(l, start_index_within_atom)] for each shell of element z."""
    out, s = [], 0
    for l in SHELLS[int(z)]:
        out.append((l, s))
        s += 2 * l + 1
    return out


def n_electrons(numbers) -> int:
    return int(sum(VALENCE_ELECTRONS_TOTAL[int(z)] for z in numbers))


def ao_real_sh(l: int, xyz: np.ndarray) -> np.ndarray:
    """Real spherical harmonics in PySCF AO component order, 'component' normalisation."""
    xyz = xyz / np.linalg.norm(xyz, axis=1, keepdims=True)
    x, y, z = xyz.T
    if l == 0:
        return np.ones((len(x), 1))
    if l == 1:
        return math.sqrt(3) * np.stack([x, y, z], 1)
    if l == 2:
        return np.stack([
            math.sqrt(15) * x * y,
            math.sqrt(15) * y * z,
            math.sqrt(5) / 2 * (3 * z * z - 1),
            math.sqrt(15) * x * z,
            math.sqrt(15) / 2 * (x * x - y * y)], 1)
    raise ValueError("only l<=2 needed for Def2-SVP H,C,N,O,F")


@functools.lru_cache(maxsize=None)
def basis_change(l: int) -> np.ndarray:
    """Orthogonal M_l with  Y_e3nn(r) = Y_ao(r) @ M_l."""
    import torch
    from e3nn import o3
    rng = np.random.default_rng(0)
    pts = rng.normal(size=(128, 3))
    pts /= np.linalg.norm(pts, axis=1, keepdims=True)
    y_e3 = o3.spherical_harmonics(l, torch.tensor(pts, dtype=torch.float64), normalize=True,
                                  normalization="component").numpy()
    y_ao = ao_real_sh(l, pts)
    M = np.linalg.lstsq(y_ao, y_e3, rcond=None)[0]
    u, _, vt = np.linalg.svd(M)
    M = u @ vt
    assert np.abs(y_ao @ M - y_e3).max() < 1e-8, f"AO/e3nn basis mismatch for l={l}"
    return M


@functools.lru_cache(maxsize=None)
def block_spec():
    """Irreps content of an atom-pair Hamiltonian block (heavy x heavy shells).

    For shell pair (la, lb) the block lives in  la x lb = |la-lb| .. la+lb  with parity
    (-1)^(la+lb).  Returns (keys, mult, offsets, comp, total_dim).
    """
    comp, mult = {}, {}
    for ha, la in enumerate(HEAVY_SHELLS):
        for hb, lb in enumerate(HEAVY_SHELLS):
            p = (-1) ** (la + lb)
            for lc in range(abs(la - lb), la + lb + 1):
                key = (lc, p)
                u = mult.get(key, 0)
                mult[key] = u + 1
                comp[(ha, hb, lc)] = (key, u)
    keys = sorted(mult, key=lambda k: (k[0], -k[1]))
    offsets, off = {}, 0
    for k in keys:
        offsets[k] = off
        off += mult[k] * (2 * k[0] + 1)
    return keys, mult, offsets, comp, off


def block_irreps():
    from e3nn import o3
    keys, mult, *_ = block_spec()
    return o3.Irreps([(mult[k], (k[0], k[1])) for k in keys])


@functools.lru_cache(maxsize=None)
def expansion_matrix(zi: int, zj: int) -> np.ndarray:
    """A of shape (n_i*n_j, D):  block_ao.flatten() = A @ irreps_vector."""
    import torch
    from e3nn import o3
    keys, mult, offsets, comp, D = block_spec()
    ni, nj = n_orbitals(zi), n_orbitals(zj)
    A = np.zeros((ni * nj, D))
    map_i = list(range(6)) if zi != 1 else list(H_TO_HEAVY)
    map_j = list(range(6)) if zj != 1 else list(H_TO_HEAVY)
    for sa, (la, oa) in enumerate(shell_offsets(zi)):
        for sb, (lb, ob) in enumerate(shell_offsets(zj)):
            ha, hb = map_i[sa], map_j[sb]
            Ma, Mb = basis_change(la), basis_change(lb)
            for lc in range(abs(la - lb), la + lb + 1):
                key, u = comp[(ha, hb, lc)]
                cg = o3.wigner_3j(la, lb, lc).double().numpy() * math.sqrt(2 * lc + 1)
                blk = np.einsum("mk,kqc,nq->mnc", Ma, cg, Mb)  # AO-basis CG block
                base = offsets[key] + u * (2 * lc + 1)
                for m in range(2 * la + 1):
                    for n in range(2 * lb + 1):
                        A[(oa + m) * nj + ob + n, base:base + 2 * lc + 1] += blk[m, n]
    return A
