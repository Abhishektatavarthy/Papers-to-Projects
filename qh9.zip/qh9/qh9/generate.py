"""Dataset generation drivers for QH9-stable and QH9-dynamic."""
from __future__ import annotations

import os
from multiprocessing import Pool
from typing import List, Optional

import numpy as np

from .dataset import SampleStore
from .qm9 import QM9Record

N_FRAMES = 100


def _stable_job(args):
    root, sid, Z, pos = args
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    store = SampleStore(root)
    if store.exists(sid):
        return sid, True
    try:
        from .dft import run_dft
        r = run_dft(Z, pos)
        store.write(sid, Z, pos, r["H"], e_tot=r["e_tot"], scf_cycles=r["scf_cycles"])
        return sid, True
    except Exception as e:  # keep going; failures are reported
        print(f"[stable {sid}] failed: {e}")
        return sid, False


def generate_stable(records: List[QM9Record], root: str, workers: int = 1):
    """DFT for every QM9 geometry. Sample id = position in `records`; mol_id = qm9_id."""
    jobs = [(root, i, r.numbers, r.positions) for i, r in enumerate(records)]
    os.makedirs(root, exist_ok=True)
    with Pool(workers) as p:
        res = list(p.imap_unordered(_stable_job, jobs, chunksize=4))
    ok = {i for i, good in res if good}
    store = SampleStore(root)
    entries = [dict(id=i, mol_id=records[i].qm9_id, frame=-1) for i in sorted(ok)]
    return store.build_index(entries)


def select_dynamic_molecules(records: List[QM9Record], n_mol: int = 999, min_atoms: int = 10,
                             max_atoms: int = 19, seed: int = 0) -> List[QM9Record]:
    """Random molecules with 10-19 atoms (range read from Table 5 / Fig. 2c; selection rule not in paper)."""
    pool = [r for r in records if min_atoms <= len(r.numbers) <= max_atoms]
    rng = np.random.default_rng(seed)
    return [pool[i] for i in rng.choice(len(pool), size=n_mol, replace=False)]


def _dynamic_job(args):
    root, mol_id, Z, pos, calc, seed = args
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    store = SampleStore(root)
    base = mol_id * N_FRAMES
    if all(store.exists(base + f) for f in range(N_FRAMES)):
        return mol_id, True
    try:
        from .dft import run_dft
        from .md import run_nve
        frames = run_nve(Z, pos, calculator=calc, seed=seed + mol_id)
        for f, geo in enumerate(frames):
            if store.exists(base + f):
                continue
            r = run_dft(Z, geo)
            store.write(base + f, Z, geo, r["H"], e_tot=r["e_tot"], scf_cycles=r["scf_cycles"])
        return mol_id, True
    except Exception as e:
        print(f"[dynamic {mol_id}] failed: {e}")
        return mol_id, False


def generate_dynamic(records: List[QM9Record], root: str, workers: int = 1, calculator: str = "pyscf",
                     n_mol: int = 999, seed: int = 0):
    mols = select_dynamic_molecules(records, n_mol=n_mol, seed=seed)
    os.makedirs(root, exist_ok=True)
    jobs = [(root, m, r.numbers, r.positions, calculator, seed) for m, r in enumerate(mols)]
    with Pool(workers) as p:
        res = list(p.imap_unordered(_dynamic_job, jobs, chunksize=1))
    good = sorted(m for m, ok in res if ok)
    entries = [dict(id=m * N_FRAMES + f, mol_id=m, frame=f) for m in good for f in range(N_FRAMES)]
    return SampleStore(root).build_index(entries)
