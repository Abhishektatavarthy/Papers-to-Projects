"""Analysis experiments from the paper: dataset statistics (Table 5), OOD intersection study (Tables 3, 6),
and training-set-size ablation (Table 7)."""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from .splits import Split


def dataset_statistics(index: List[dict], split: Split) -> Dict[str, Dict[str, str]]:
    by_id = {e["id"]: e for e in index}
    out = {}
    for field in ("n_atoms", "n_electrons", "n_orbitals"):
        out[field] = {}
        for k in ("train", "valid", "test"):
            v = np.array([by_id[i][field] for i in split[k]])
            out[field][k] = dict(mean=float(v.mean()), median=float(np.median(v)), max=int(v.max()), min=int(v.min()))
    return out


def ood_intersection(id_split: Split, ood_split: Split) -> np.ndarray:
    """Evaluation set for the ID-vs-OOD training comparison: test(id) ∩ test(ood).
    (Paper: 923 molecules with 23-29 atoms.)"""
    return np.intersect1d(id_split["test"], ood_split["test"])


def group_by_size(ids: np.ndarray, index: List[dict]) -> Dict[int, np.ndarray]:
    by_id = {e["id"]: e["n_atoms"] for e in index}
    sizes = np.array([by_id[i] for i in ids])
    return {int(n): ids[sizes == n] for n in np.unique(sizes)}


def subsample_train(split: Split, n: int, seed: int = 0) -> Split:
    """Training-size ablation (Table 7): keep n random training examples (paper: 50k and 10k)."""
    keep = np.random.default_rng(seed).choice(split["train"], size=n, replace=False)
    return {**split, "train": keep}
