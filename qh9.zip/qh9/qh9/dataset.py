"""On-disk sample store, torch Dataset and batch collation.

Each sample is one .npz (Z, pos[Angstrom], H[Hartree, float64, PySCF AO order], e_tot, scf_cycles)
stored at  <root>/samples/<id//1000>/<id>.npz ; <root>/index.json lists metadata per sample id.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

from .orbitals import n_electrons, n_orbitals


class SampleStore:
    def __init__(self, root: str):
        self.root = root

    def path(self, sid: int) -> str:
        return os.path.join(self.root, "samples", f"{sid // 1000:05d}", f"{sid:07d}.npz")

    def exists(self, sid: int) -> bool:
        return os.path.exists(self.path(sid))

    def write(self, sid: int, numbers, positions, H, **extra) -> None:
        p = self.path(sid)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp.npz"
        np.savez(tmp, Z=np.asarray(numbers, dtype=np.int8), pos=np.asarray(positions, dtype=np.float64),
                 H=np.asarray(H, dtype=np.float64), **extra)
        os.replace(tmp, p)

    def read(self, sid: int, with_H: bool = True) -> dict:
        with np.load(self.path(sid)) as d:
            out = dict(Z=d["Z"].astype(np.int64), pos=d["pos"])
            if with_H:
                out["H"] = d["H"]
            return out

    def build_index(self, entries: Sequence[dict], name: str = "index.json") -> List[dict]:
        """entries: dicts with id, mol_id, frame (frame=-1 for stable). Adds n_atoms/n_electrons/n_orbitals."""
        idx = []
        for e in entries:
            Z = self.read(e["id"], with_H=False)["Z"]
            idx.append({**e, "n_atoms": int(len(Z)), "n_electrons": n_electrons(Z),
                        "n_orbitals": int(sum(n_orbitals(z) for z in Z))})
        with open(os.path.join(self.root, name), "w") as fh:
            json.dump(idx, fh)
        return idx

    def load_index(self, name: str = "index.json") -> List[dict]:
        with open(os.path.join(self.root, name)) as fh:
            return json.load(fh)


class QH9Dataset:
    """Map-style dataset over a list of sample ids."""

    def __init__(self, root: str, ids: Sequence[int]):
        self.store = SampleStore(root)
        self.ids = np.asarray(ids, dtype=np.int64)

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        sid = int(self.ids[i])
        s = self.store.read(sid)
        s["id"] = sid
        return s


@dataclass
class Batch:
    z: "torch.Tensor"
    pos: "torch.Tensor"
    batch: "torch.Tensor"          # atom -> molecule
    ao_off: "torch.Tensor"         # atom -> first AO index inside its molecule
    mol_nao: "torch.Tensor"        # (B,)
    mol_base: "torch.Tensor"       # (B,) offset of molecule's flattened HxH block
    transpose_idx: "torch.Tensor"  # flat index permutation giving H^T
    H: Optional["torch.Tensor"]    # flat target (float32) or None
    diag_mask: "torch.Tensor"      # flat bool: element inside an atom-diagonal block
    elem_mol: "torch.Tensor"       # flat element -> molecule
    ids: List[int]

    def to(self, device):
        for k, v in self.__dict__.items():
            if hasattr(v, "to"):
                setattr(self, k, v.to(device))
        return self


def collate(samples: List[dict]) -> Batch:
    import torch
    zs, poss, bs, offs, nao_l, base_l, tidx, Hs, dmask, emol, ids = [], [], [], [], [], [], [], [], [], [], []
    base = 0
    for m, s in enumerate(samples):
        Z = s["Z"]
        nao_atoms = np.array([n_orbitals(z) for z in Z])
        off = np.concatenate([[0], np.cumsum(nao_atoms)[:-1]])
        nao = int(nao_atoms.sum())
        zs.append(Z); poss.append(s["pos"]); bs.append(np.full(len(Z), m)); offs.append(off)
        nao_l.append(nao); base_l.append(base)
        tidx.append(np.arange(nao * nao).reshape(nao, nao).T.reshape(-1) + base)
        atom_of_ao = np.repeat(np.arange(len(Z)), nao_atoms)
        dmask.append((atom_of_ao[:, None] == atom_of_ao[None, :]).reshape(-1))
        emol.append(np.full(nao * nao, m))
        if "H" in s:
            Hs.append(s["H"].reshape(-1))
        ids.append(s.get("id", -1))
        base += nao * nao
    cat = np.concatenate
    return Batch(
        z=torch.from_numpy(cat(zs)), pos=torch.from_numpy(cat(poss)).float(),
        batch=torch.from_numpy(cat(bs)), ao_off=torch.from_numpy(cat(offs)),
        mol_nao=torch.tensor(nao_l), mol_base=torch.tensor(base_l),
        transpose_idx=torch.from_numpy(cat(tidx)),
        H=torch.from_numpy(cat(Hs)).float() if Hs else None,
        diag_mask=torch.from_numpy(cat(dmask)), elem_mol=torch.from_numpy(cat(emol)), ids=ids)


def make_loader(ds: QH9Dataset, batch_size: int, shuffle: bool, num_workers: int = 4, drop_last: bool = False):
    import torch
    return torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers,
                                       collate_fn=collate, drop_last=drop_last, persistent_workers=num_workers > 0)


def split_flat_to_matrices(flat: np.ndarray, mol_nao: Sequence[int], mol_base: Sequence[int]) -> List[np.ndarray]:
    return [flat[b:b + n * n].reshape(n, n) for n, b in zip(mol_nao, mol_base)]
