# qh9 — QH9-style quantum Hamiltonian benchmark

Re-implementation, from the paper's description, of: DFT data generation (PySCF), the four benchmark
splits, a QHNet-style SE(3)-equivariant Hamiltonian predictor (e3nn), the training recipe, and the
evaluation metrics (H MAE, orbital energies, orbital-coefficient cosine, DFT acceleration ratios).
**It is not the official QHBench code** (github.com/divelab/AIRS/tree/main/OpenDFT/QHBench).

```bash
pip install -e .            # numpy scipy torch e3nn pyscf tqdm   (+ ase for MD:  pip install -e .[md])
pytest tests                # 11 tests

# 1. data (QM9 xyz files + uncharacterized.txt from figshare 978904 -> 130,831 molecules)
qh9 gen-stable  --qm9-dir QM9/xyz --uncharacterized QM9/uncharacterized.txt --out data/qh9_stable  --workers 32
qh9 gen-dynamic --qm9-dir QM9/xyz --uncharacterized QM9/uncharacterized.txt --out data/qh9_dynamic --workers 32
# 2. splits   (stable-id | stable-ood | dynamic-geo | dynamic-mol)
qh9 split --root data/qh9_stable --task stable-id
# 3. train / evaluate
qh9 train --root data/qh9_stable --split data/qh9_stable/split_stable-id.json --out runs/stable-id
qh9 eval  --root data/qh9_stable --split data/qh9_stable/split_stable-id.json --ckpt runs/stable-id/best.pt --accel
```

## Map: paper -> code
| Paper | Module |
|---|---|
| Sec 3.1 DFT settings (B3LYP, Def2-SVP, grid 3, tol 1e-13, grad 3.16e-5, DIIS 8) | `dft.py` |
| Sec 3.1 NVE MD (300 K, 0.12 fs, 1000 steps, 100 frames every 10) | `md.py`, `generate.py` |
| QM9 130,831 molecules | `qm9.py` |
| Sec 3.2 / Table 1 splits | `splits.py` |
| Sec 3.3 QHNet baseline (5 interaction layers, expansion to full-orbital blocks) | `model.py`, `orbitals.py` |
| Sec 4 training (batch 32, warm-up 1k to 5e-4, linear decay to 1e-7) | `train.py` |
| Sec 3.4 metrics, Table 4 acceleration ratios | `metrics.py`, `accel.py`, `evaluate.py` |
| Tables 3, 5, 6, 7 (OOD study, statistics, size ablation) | `analysis.py` |

## How equivariance is handled
Orbital layout is Def2-SVP in PySCF order (H: s s p = 5 AOs; C/N/O/F: s s s p p d = 14). For every
element pair, `orbitals.expansion_matrix` maps irreps outputs (shell pair (la,lb) -> l in |la-lb|..la+lb,
parity (-1)^(la+lb)) to the AO block via Clebsch-Gordan coefficients and an orthogonal basis change
between PySCF's real harmonics and e3nn's (computed numerically, verified against PySCF's own AOs).
Predictions are symmetrised, `H = (H + H^T)/2`.

## Verified here (tests pass)
AO layout vs PySCF; p/d harmonic conventions vs PySCF; DFT Hamiltonian satisfies HC = eSC; split
counts equal Table 1 (104,664/13,083/13,084; 79,920/9,990/9,990; 79,900/9,900/10,100); model output is
symmetric, rotation-equivariant (checked with Wigner-D in the AO basis) and permutation-equivariant;
end-to-end smoke run (DFT -> index -> split -> train -> eval -> acceleration) on a 20-sample toy set.

## NOT verified / not reproduced
* No large-scale run: full data generation and 210k-260k-step training were not executed, so **no
  paper numbers are reproduced**. A 60-step toy run only shows that the code runs.
* `gen-dynamic` was tested for 20 MD steps only; `qm9.py` on a synthetic file only.

## Unspecified in the paper (my choices - change if you have the official details)
* MD engine / forces (ASE velocity-Verlet; PySCF B3LYP forces at lower SCF tolerance, or xTB), choice of
  the 999 dynamic molecules (random, 10-19 atoms, from Table 5 / Fig. 2c), random seeds.
* Model widths (`hidden_mul=64`, `pair_mul=24`, cutoff 12 A, 32 RBFs) and the exact QHNet layer
  design; loss = MAE + MSE on H (from my recollection of QHNet); AdamW, grad-clip 10; which task
  uses 210k vs 260k steps (default 260k).
* Metric details: MAE is averaged per molecule; cosine similarity uses |cos| per occupied orbital and
  ignores degeneracy; error-level / achieved ratios follow my reading of the prose in Sec. 3.4.
* PySCF `b3lyp` is PySCF's variant of B3LYP (may differ from other codes).
